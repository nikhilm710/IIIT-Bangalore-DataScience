# Load packages 

library(dplyr)
library(ggplot2)
library(tidyr)
library(stringr)
library(lubridate)
library(scales)

uber_data <- read.csv("Uber Request Data.csv",stringsAsFactors = FALSE)


#Total number of NA value for Request id-0
sum(is.na(uber_data$Request.id))


#Total number of NA value for Time of request-0
sum(is.na(uber_data$Request.timestamp))

#Total number of NA value for Pick-up point-0
sum(is.na(uber_data$Pickup.point))

#Total number of NA value for driver-2650
sum(is.na(uber_data$Driver.id))

# Status of request for which driver id is NA-"No Cars Available"
unique(uber_data$Status[which(is.na(uber_data$Driver.id))])

# We can assign driver id to 0 as no driver is assigned for that request
uber_data$Driver.id[which(is.na(uber_data$Driver.id))] <- 0

#Total number of NA value for status-0
sum(is.na(uber_data$Status))

#Total number of NA for Drop timestamp--3914
sum(is.na(uber_data$Drop.timestamp))

# Status of request for which Drop timestamp is NA-"No Cars Available and "Cancelled""
unique(uber_data$Status[which(is.na(uber_data$Drop.timestamp))])
#Assign Na Values to  "31-12-2099 00:00:00" so that we make all the values to date timestamp.
uber_data$Drop.timestamp[which(is.na(uber_data$Drop.timestamp))] <- "31-12-2099 00:00:00"

#converting column Request.timestamp into date-timestamp  value
#convert the value to date timestamp for which second is not present
dmyhm_request_timestamp <- dmy_hm(uber_data$Request.timestamp)

#convert the value to date timestamp for which second is present
dmyhms_request_timestamp <- dmy_hms(uber_data$Request.timestamp)
#merge all the value
dmyhm_request_timestamp[is.na(dmyhm_request_timestamp)] <- dmyhms_request_timestamp[!is.na(dmyhms_request_timestamp)]

#assign all the value to uber data request timestamp column
uber_data$Request.timestamp <-  dmyhm_request_timestamp


#converting column Drop.timestamp into date-timestamp value
#convert the value to date timestamp for which second is not present
dmyhm_drop_timestamp <- dmy_hm(uber_data$Drop.timestamp)

#convert the value to date timestamp for which second is present
dmyhms_drop_timestamp <- dmy_hms(uber_data$Drop.timestamp)

#merge all the value
dmyhm_drop_timestamp[is.na(dmyhm_drop_timestamp)] <- dmyhms_drop_timestamp[!is.na(dmyhms_drop_timestamp)]

uber_data$Drop.timestamp <- dmyhm_drop_timestamp

#Make two new colmuns request date and request time
uber_data<- uber_data %>% mutate(request_date = date(Request.timestamp),request_time =  strftime(uber_data$Request.timestamp,format="%H:%M:%S",tz="GMT"))

#Creating timeslot column based on the request time
uber_data$time_slot <- ifelse((uber_data$request_time>="04:00:01" & uber_data$request_time <= "08:00:00"),"Early Morning",ifelse((uber_data$request_time>="08:00:01" & uber_data$request_time <="12:00:00"),"Morning",ifelse((uber_data$request_time >= "12:00:01" & uber_data$request_time <= "16:00:00"),"Afternoon",ifelse((uber_data$request_time>= "16:00:01"  & uber_data$request_time<= "20:00:00"),"Evening",ifelse((uber_data$request_time >= "20:00:01" & uber_data$request_time <= "23:59:59"),"Night","LateNight")))))


#1.Visually identify the most pressing problems for Uber. 
#1.1 frequency of requests that get cancelled or show 'no cars available'

uber_data %>% filter(Status=="Cancelled" | Status=="No Cars Available") %>%  ggplot(aes(x=Pickup.point,fill=Status)) + geom_bar() + labs(x="Request",y="Frequency",title="Plot of Frequency of Request")

# Number of request based on time:

uber_data %>% group_by(hours = format(strptime(request_time,"%H:%M:%S"),'%H')) %>%  ggplot(aes(x=hours,fill=Status)) + geom_bar()  + labs(x="Hour",y="Frequency",title="Plot of Frequncy of request vs time")

# Number of request based on time slot:

uber_data %>% group_by(time_slot) %>% ggplot(aes(x=time_slot,fill=Status)) + geom_bar()  +  labs(x="Time Slot",y="Frequency",title="Plot of Frequncy of request vs Time slot")

# Number of request based on pickuppoint:

uber_data %>% group_by(Pickup.point) %>%  ggplot(aes(x=Pickup.point,fill=Status)) + geom_bar() +  labs(x="Pick up point",y="Frequency",title="Plot of Frequncy of request vs Pickup Point")


#1.2 identify the most problematic types of requests (city to airport / airport to city etc.) 
#and the time slots (early mornings, late evenings etc.) using plots

uber_data %>% filter(Status=="Cancelled" | Status=="No Cars Available") %>% ggplot(aes(x=time_slot,fill=Pickup.point)) + geom_bar() + labs(x="Time Slot",y="Frequency",title="Problemetic request type plot")
# Evening time slot i.e time between 16:00:01 and 20:00:00 and request = Airport to city is most problemetic

# Number of request based on time:
uber_data %>% group_by(hours = format(strptime(request_time,"%H:%M:%S"),'%H')) %>% ggplot(aes(x=hours,fill=Status)) + geom_bar()
#Frequency of request that got complted - Most of the trip got compltetd during Early morning hours i.e 4:00 A.M to 8:00 A.M
uber_data %>% filter(Status=="Trip Completed") %>% ggplot(aes(x=time_slot,fill=Pickup.point)) +  geom_bar() + labs(x="Time Slot",y="Frequency",title="Plot of Frequency of Request that got completed")

#Trips during different time slot
ggplot(uber_data,aes(x=time_slot,fill=Status)) + geom_bar(position = "dodge")+labs(x="Time Slot",y="Frequency",title="Trip during different time slot")
#findings:
#a.Most trip got cancelled in early morning hours
#b.Cars are not available for most of the request in Evening hours

#2 Find out the gap between supply and demand and show the same using plots.

#2.a Calculation of demand and supply
uber_data %>% summarise(Total_requests=n(),Total_request_complted=sum(Status=="Trip Completed"))
#Result- Total 6745 request are made and out of that only 2831 request i.e 42% request got completed
 
 uber_data %>% summarise(Percent_trip_completed =round(sum(Status=="Trip Completed")/n()*100,2),percent_Cancelled_trip=round(sum(Status=="Cancelled" )/n()*100,2),percent_carsnotavailable_trip=round(sum( Status=="No Cars Available")/n()*100,2))
 
 
 #Time slot when the highest gap exists- Early morning time slot gap exists the most
 
 
 uber_data %>% group_by(time_slot) %>% summarise(gap=n()-sum(Status=="Cancelled" | Status=="No Cars Available")) %>% ggplot(aes(x=time_slot,fill=time_slot))  + geom_bar(aes(y=gap),stat="identity") +labs(x="Time Slot",y="Gap",title="Plot of time slot with supply demand gap")
 
                                                                                                                             

 #types of requests (city-airport or airport-city) for which the gap is the most severe in the identified time slots- For request type city to airport gap exists the most

uber_data %>% filter(time_slot=="Early Morning") %>% group_by(Pickup.point) %>% summarise(gap=n()-sum(Status=="Cancelled" | Status=="No Cars Available"))  %>% ggplot(aes(x=Pickup.point,fill=Pickup.point)) + geom_bar(aes(y=gap),stat="identity") +labs(x="Request Type",y="Gap",title="Plot of Request type with supply demand gap in Early Morning time slot")



#Main reason for gap is trip cancellation
# summary of demand and supply of request from city during Early morning timeslot
uber_data %>% filter(time_slot=="Early Morning" & Pickup.point=="City") %>% summarise(request_made=n(),Cancelled_request= sum(Status=='Cancelled'), Car_availabilty=sum(Status=="No Cars Available") )
# summary of demand and supply of request from Airport during Early morning timeslot
uber_data %>% filter(time_slot=="Early Morning" & Pickup.point=="Airport") %>% summarise(request_made=n(),Cancelled_request= sum(Status=='Cancelled'), Car_availabilty=sum(Status=="No Cars Available") )
#Graph to show no of trip cancelled, cabs not avaibale and trip completed for early morning slot
uber_data %>% filter(time_slot=="Early Morning" & Pickup.point=="City") %>% ggplot(aes(x=factor(Status),fill=Status)) + geom_bar()

 