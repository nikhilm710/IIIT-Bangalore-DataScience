#Loading the required libraries

library(forecast)
library(tseries)
require(graphics)
library(dplyr)
library(zoo)
library(TTR)
#loading the file into R

global_superstore <- read.csv("Global Superstore.csv")
str(global_superstore)

##changing the order.date in date format and sorting the data as per the order date
global_superstore$Order.Date <- as.Date(global_superstore$Order.Date, format="%d-%m-%Y")
global_superstore <- global_superstore[order(global_superstore$Order.Date),]

##Extracting Month and Year from the date which will later help to take aggreagate on

global_superstore$Order_MonthYear <- format(global_superstore$Order.Date, "%Y-%m")

global_superstore$Order_MonthYear <- as.yearmon(global_superstore$Order_MonthYear, "%Y-%m")

str(global_superstore)

##Checking levels of segment and market

levels (global_superstore$Segment) #- 3 levles ("Consumer"    "Corporate"   "Home Office")
levels (global_superstore$Segment)[3] <- "Home_Office"
levels (global_superstore$Market)#- 7 levles ("Africa", "APAC","Canada","EMEA","EU","LATAM","US") 

##Creating subsets for each of these levels from above to get 21 subsets, created CV variable and the data is also orderd as eper Month and year


for (i in 1:3) {
  for (j in 1:7){
    
    df<- global_superstore%>% filter(Segment == levels (global_superstore$Segment)[i], Market == levels (global_superstore$Market)[j])
    df<- df %>% select(Order_MonthYear, Sales, Quantity, Profit)
    df<- df %>%  group_by(Order_MonthYear) %>% summarise_all(funs(sum))
    df_cv <- sd(df$Profit)/mean(df$Profit)*100
    df_sp <- sum(df$Profit)
    
    Market <- levels (global_superstore$Market)[j]
    Segment <- levels (global_superstore$Segment)[i]
    
    assign(paste(Segment, Market, sep='_'),df)
    assign(paste(Segment, Market, sep='_cv_'),df_cv)
    assign(paste(Segment, Market, sep='_sp_'),df_sp)
  }
}

# We can see that Cosumer APAC has very less cv of 63 and highest total profit of 222817.
#Consumer EU category has cv of 62 and second highest profit of 188687.

#So, we choose Consumer APAC and Consumer EU subsets. 


##1## Creating time series for Consumer APAC sales, all except the last 6 months data

indata_consumer_APAC_sales <- Consumer_APAC [1:42,]
total_timeser_consumer_APAC_sales <- ts(Consumer_APAC$Sales)
timeser_sales_consumer_APAC <- ts(indata_consumer_APAC_sales$Sales)
plot(timeser_sales_consumer_APAC)

detach(package:dplyr)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries_consumer_APAC_sales <- filter(timeser_sales_consumer_APAC, 
                         filter=rep(1/(2*w+1),(2*w+1)), 
                         method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries_consumer_APAC_sales[w+2] - smoothedseries_consumer_APAC_sales[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_consumer_APAC_sales[i] <- smoothedseries_consumer_APAC_sales[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser_sales_consumer_APAC)
diff <- smoothedseries_consumer_APAC_sales[n-w] - smoothedseries_consumer_APAC_sales[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_consumer_APAC_sales[i] <- smoothedseries_consumer_APAC_sales[i-1] + diff
}

#Plot the smoothed time series
indata_consumer_APAC_sales$Month <- c(1:42)

timevals_in_consumer_APAC_sales <- indata_consumer_APAC_sales$Month
lines(smoothedseries_consumer_APAC_sales, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf_consumer_APAC_sales <- as.data.frame(cbind(timevals_in_consumer_APAC_sales, as.vector(smoothedseries_consumer_APAC_sales)))
colnames(smootheddf_consumer_APAC_sales) <- c('Month', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit_consumer_APAC_sales <- lm(Sales ~ sin(0.5*Month) * poly(Month, 3.5) + cos(0.5*Month) * poly(Month,3.5)
                         + Month, data=smootheddf_consumer_APAC_sales)
global_pred_consumer_APAC_sales <- predict(lmfit_consumer_APAC_sales, Month=timevals_in_consumer_APAC_sales)
summary(global_pred_consumer_APAC_sales)
lines(timevals_in_consumer_APAC_sales, global_pred_consumer_APAC_sales, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred_consumer_APAC_sales <- timeser_sales_consumer_APAC -global_pred_consumer_APAC_sales
plot(local_pred_consumer_APAC_sales, col='red', type = "l")
acf(local_pred_consumer_APAC_sales)
acf(local_pred_consumer_APAC_sales, type="partial")
armafit_consumer_APAC_sales <- auto.arima(local_pred_consumer_APAC_sales)

tsdiag(armafit_consumer_APAC_sales)
armafit_consumer_APAC_sales

#We'll check if the residual series is white noise

resi_consumer_APAC_sales <- local_pred_consumer_APAC_sales-fitted(armafit_consumer_APAC_sales)
auto.arima(resi_consumer_APAC_sales) ##Arima (0,0,0) model indicatiing stationary series

adf.test(resi_consumer_APAC_sales,alternative = "stationary")## p=0.01 < 0.05
kpss.test(resi_consumer_APAC_sales) ##p =0.1 confirming it is stationary

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months


outdata_consumer_APAC <- Consumer_APAC[43:48,]
outdata_consumer_APAC$Month <- c(43:48)

timevals_out_consumer_APAC <- outdata_consumer_APAC$Month

outdata_consumer_APAC1 <- outdata_consumer_APAC[,2]
outdata_consumer_APAC1 <- cbind(timevals_out_consumer_APAC, outdata_consumer_APAC1)


#library(dplyr)

global_pred_out_consumer_APAC_sales <- predict(lmfit_consumer_APAC_sales,data.frame(Month =timevals_out_consumer_APAC))

fcast_sales_consumer_APAC <- global_pred_out_consumer_APAC_sales
#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec_cons_apac_sales <- accuracy(fcast_sales_consumer_APAC,outdata_consumer_APAC1[,2])[5]
MAPE_class_dec_cons_apac_sales ##MAPE is 31

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred <- c(ts(global_pred_consumer_APAC_sales),ts(global_pred_out_consumer_APAC_sales))
plot(total_timeser_consumer_APAC_sales, col = "black")
lines(class_dec_pred, col = "red")



#So, that was classical decomposition, now let's do an ARIMA fit

autoarima_consumer_APAC_sales <- auto.arima(timeser_sales_consumer_APAC)
autoarima_consumer_APAC_sales
tsdiag(autoarima_consumer_APAC_sales)
plot(autoarima_consumer_APAC_sales$x, col="black")
lines(fitted(autoarima_consumer_APAC_sales), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima_consumer_APAC_sales <- timeser_sales_consumer_APAC - fitted(autoarima_consumer_APAC_sales)
auto.arima(resi_auto_arima_consumer_APAC_sales) ##ARIMA (0,0,0) indicating it is stationary
adf.test(resi_auto_arima_consumer_APAC_sales ,alternative = "stationary") #ADF test gives p=0.01 which is p<0.05
kpss.test(resi_auto_arima_consumer_APAC_sales)#P=0.1 haence residue is noise

#Also, let's evaluate the model using MAPE
fcast_auto_arima_consumer_APAC_sales <- predict(autoarima_consumer_APAC_sales, n.ahead = 6)


fcast_auto_arima_consumer_APAC_sales <- data.frame(fcast_auto_arima_consumer_APAC_sales)

MAPE_auto_arima_consumer_APAC_sales <- accuracy(fcast_auto_arima_consumer_APAC_sales$pred,outdata_consumer_APAC1[,2])[5]

MAPE_auto_arima_consumer_APAC_sales ##MAPE is 27

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit


auto_arima_pred_consumer_APAC_sales <- c(fitted(autoarima_consumer_APAC_sales ),fcast_auto_arima_consumer_APAC_sales$pred)
plot(total_timeser_consumer_APAC_sales, col = "black")
lines(auto_arima_pred_consumer_APAC_sales, col = "red")

##This ARIMA fit has a D variable as 1 but still it predicts the sales same for next 6 months, so we will not use this model
##We will use classical decomposition. 


##Predicting 6 months future Sales for Home office EMEA


F6_consumer_APAC_sales <- data.frame(c(49:54))
colnames(F6_consumer_APAC_sales)[1] <- "Month"

F6_predict_consumer_APAC_sales<- predict(lmfit_consumer_APAC_sales ,data.frame(Month =F6_consumer_APAC_sales$Month))

F6_predict_consumer_APAC_sales <- data.frame(F6_predict_consumer_APAC_sales)

#Next 6 months sales are 48894, 55229, 59321, 57988, 49177, 33068


#----------------------------------------------------------------------------------------------------------------------
##2## Creating time series for consumer APAC Quantity all except last 6 months data

indata_consumer_APAC <- Consumer_APAC [1:42,]
total_timeser_consumer_APAC_Quantity <- ts(Consumer_APAC$Quantity)
timeser_Quantity_consumer_APAC <- ts(indata_consumer_APAC$Quantity)
plot(timeser_Quantity_consumer_APAC)

detach(package:dplyr)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries_consumer_APAC_Quantity <- filter(timeser_Quantity_consumer_APAC, 
                              filter=rep(1/(2*w+1),(2*w+1)), 
                              method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries_consumer_APAC_Quantity[w+2] - smoothedseries_consumer_APAC_Quantity[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_consumer_APAC_Quantity[i] <- smoothedseries_consumer_APAC_Quantity[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser_Quantity_consumer_APAC)
diff <- smoothedseries_consumer_APAC_Quantity[n-w] - smoothedseries_consumer_APAC_Quantity[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_consumer_APAC_Quantity[i] <- smoothedseries_consumer_APAC_Quantity[i-1] + diff
}

#Plot the smoothed time series
indata_consumer_APAC$Month <- c(1:42)

timevals_in_consumer_APAC_quantity <- indata_consumer_APAC$Month
lines(smoothedseries_consumer_APAC_Quantity, col="blue", lwd=2)
#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf_consumer_APAC_quantity <- as.data.frame(cbind(timevals_in_consumer_APAC_quantity, as.vector(smoothedseries_consumer_APAC_Quantity)))
colnames(smootheddf_consumer_APAC_quantity) <- c('Month', 'Quantity')



#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit_consumer_APAC_quantity <- lm(Quantity ~ sin(0.5*Month)* poly(Month, 3) + cos(0.5*Month)* poly(Month,3)
                            + Month, data=smootheddf_consumer_APAC_quantity)
global_pred_consumer_APAC_quantity <- predict(lmfit_consumer_APAC_quantity, Month=timevals_in_consumer_APAC_quantity)
summary(global_pred_consumer_APAC_quantity )
lines(timevals_in_consumer_APAC_quantity, global_pred_consumer_APAC_quantity, col='red', lwd=2)
#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred_consumer_APAC_quantity <- timeser_Quantity_consumer_APAC-global_pred_consumer_APAC_quantity
plot(local_pred_consumer_APAC_quantity, col='red', type = "l")
acf(local_pred_consumer_APAC_quantity)
acf(local_pred_consumer_APAC_quantity, type="partial")
armafit_consumer_APAC_qunatity <- auto.arima(local_pred_consumer_APAC_quantity)

tsdiag(armafit_consumer_APAC_qunatity)
armafit_consumer_APAC_qunatity

#We'll check if the residual series is white noise

resi_consumer_APAC_quantity <- local_pred_consumer_APAC_quantity -fitted(armafit_consumer_APAC_qunatity )
auto.arima(resi_consumer_APAC_quantity)##ARIMA 0,0,0 model which indicates this as a stationary series

adf.test(resi_consumer_APAC_quantity,alternative = "stationary") ##p=0.01 which is less than 0.05

kpss.test(resi_consumer_APAC_quantity)## p=0.1 indicating that the residue is stationary or noise. 


#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months


outdata_consumer_APAC<- Consumer_APAC[43:48,]
outdata_consumer_APAC$Month <- c(43:48)

timevals_out_consumer_APAC <- outdata_consumer_APAC$Month

outdata_consumer_APAC_quantity <- outdata_consumer_APAC[,3]
outdata_consumer_APAC_quantity <- cbind(timevals_out_consumer_APAC, outdata_consumer_APAC_quantity)

library(dplyr)
#detach(package:dplyr)

global_pred_out_consumer_APAC_qunatity <- predict(lmfit_consumer_APAC_quantity,data.frame(Month =timevals_out_consumer_APAC))

fcast_consumer_APAC_qunatity <- global_pred_out_consumer_APAC_qunatity

#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec_consumer_apac_quantity <- accuracy(fcast_consumer_APAC_qunatity,outdata_consumer_APAC_quantity[,2])[5]
MAPE_class_dec_consumer_apac_quantity ##MAPE is around 62. 

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred_consumer_APAC <- c(ts(global_pred_consumer_APAC_quantity),ts(global_pred_out_consumer_APAC_qunatity))
plot(total_timeser_consumer_APAC_Quantity, col = "black")
lines(class_dec_pred_consumer_APAC, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

autoarima_consumer_APAC_quantity <- auto.arima(timeser_Quantity_consumer_APAC, D=1)
autoarima_consumer_APAC_quantity
tsdiag(autoarima_consumer_APAC_quantity)
plot(autoarima_consumer_APAC_quantity$x, col="black")
lines(fitted(autoarima_consumer_APAC_quantity), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima_consumer_APAC_quantity <- timeser_Quantity_consumer_APAC - fitted(autoarima_consumer_APAC_quantity)
auto.arima(resi_auto_arima_consumer_APAC_quantity)

adf.test(resi_auto_arima_consumer_APAC_quantity,alternative = "stationary")#P value is 0.01 which is < 0.05
kpss.test(resi_auto_arima_consumer_APAC_quantity)##P value is 0.1, so abpove tests indicates the residue is not noise. 


#Also, let's evaluate the model using MAPE
fcast_auto_arima_consumer_APAC_quantity <- predict(autoarima_consumer_APAC_quantity, n.ahead = 6)
#fcast_auto_arima <- forecast(autoarima, h=6)

fcast_auto_arima_consumer_APAC_quantity  <- data.frame(fcast_auto_arima_consumer_APAC_quantity)

MAPE_auto_arima_consumer_APAC_quantity <- accuracy(fcast_auto_arima_consumer_APAC_quantity$pred,outdata_consumer_APAC_quantity[,2])[5]
MAPE_auto_arima_consumer_APAC_quantity ##MAPE is 26 which is smaller than classical decomposition. 

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit


auto_arima_pred <- c(fitted(autoarima_consumer_APAC_quantity),fcast_auto_arima_consumer_APAC_quantity$pred)
plot(total_timeser_consumer_APAC_Quantity, col = "black")
lines(auto_arima_pred, col = "red")

#Auto Arima model is predicting the same value even after introducing D=1, so it is not useful. 
# We will use classical decomposition for predicting

##Predicting 6 monts future quantity for Consumer APAC

F6_consumer_APAC_quantity <- data.frame(c(49:54))
colnames(F6_consumer_APAC_quantity)[1] <- "Month"

F6_consumer_APAC_quantity1 <- predict(lmfit_consumer_APAC_quantity,data.frame(Month =F6_consumer_APAC_quantity$Month))

F6_consumer_APAC_quantity1<- data.frame(F6_consumer_APAC_quantity1)

##Quantity for next 6 month for Home office EMEA will be 1008, 770, 539, 393, 404, 623
#-------------------------------------------------------------------------------------------------------------
##3## Creating time series for Consumer EU sales which is all except the last 6 months data

indata_consumer_EU <- Consumer_EU [1:42,]
total_timeser_consumer_EU_sales <- ts(Consumer_EU$Sales)
timeser_sales_consumer_EU <- ts(indata_consumer_EU$Sales)
plot(timeser_sales_consumer_EU)

detach(package:dplyr)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries_consumer_EU_sales <- filter(timeser_sales_consumer_EU, 
                                  filter=rep(1/(2*w+1),(2*w+1)), 
                                  method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries_consumer_EU_sales[w+2] - smoothedseries_consumer_EU_sales[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_consumer_EU_sales[i] <- smoothedseries_consumer_EU_sales[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser_sales_consumer_EU)
diff <-  smoothedseries_consumer_EU_sales[n-w] -  smoothedseries_consumer_EU_sales[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_consumer_EU_sales[i] <-  smoothedseries_consumer_EU_sales[i-1] + diff
}

#Plot the smoothed time series
indata_consumer_EU$Month <- c(1:42)

timevals_consumer_EU <- indata_consumer_EU$Month
lines(smoothedseries_consumer_EU_sales, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf_consumer_EU_sales <- as.data.frame(cbind(timevals_consumer_EU, as.vector(smoothedseries_consumer_EU_sales)))
colnames(smootheddf_consumer_EU_sales) <- c('Month', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit_consumer_EU_sales <- lm(Sales ~ sin(0.4*Month) * poly(Month,2.5)  + cos(0.4*Month) * poly(Month,2.5)
                     + Month, data=smootheddf_consumer_EU_sales)
global_pred_consumer_EU_sales<- predict(lmfit_consumer_EU_sales, Month=timevals_consumer_EU)
summary(global_pred_consumer_EU_sales)
lines(global_pred_consumer_EU_sales, global_pred_consumer_EU_sales, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred_consumer_EU_sales <- timeser_sales_consumer_EU - global_pred_consumer_EU_sales
plot(local_pred_consumer_EU_sales, col='red', type = "l")
acf(local_pred_consumer_EU_sales)
acf(local_pred_consumer_EU_sales, type="partial")
armafit_consumer_EU_sales <- auto.arima(local_pred_consumer_EU_sales)

tsdiag(armafit_consumer_EU_sales)
armafit_consumer_EU_sales

#We'll check if the residual series is white noise

resi_auto_arima_consumer_EU_sales <- local_pred_consumer_EU_sales-fitted(armafit_consumer_EU_sales)
auto.arima(resi_auto_arima_consumer_EU_sales)##ARIMA 0,0,0 model for residue so indicating it as stationaery. 

adf.test(resi_auto_arima_consumer_EU_sales,alternative = "stationary")#P=0.01 less than 0.05
kpss.test(resi_auto_arima_consumer_EU_sales)#P=0.1 greter than 0.0.05 indicating residue is noise. 

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months


outdata_consumer_EU <- Consumer_EU[43:48,]
outdata_consumer_EU$Month <- c(43:48)

timevals_out_consumer_EU <- outdata_consumer_EU$Month

outdata_consumer_EU_sales <- outdata_consumer_EU[,2]
outdata_consumer_EU_sales <- cbind(timevals_out_consumer_EU, outdata_consumer_EU_sales)

global_pred_consumer_EU_sales_out <- predict(lmfit_consumer_EU_sales,data.frame(Month =timevals_out_consumer_EU))

fcast_consumer_EU_sales <- global_pred_consumer_EU_sales_out

#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec_consumer_EU_sales <- accuracy(fcast_consumer_EU_sales,outdata_consumer_EU_sales[,2])[5]
MAPE_class_dec_consumer_EU_sales##Mape is 32

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred_consumer_EU_sales  <- c(ts(global_pred_consumer_EU_sales),ts(global_pred_consumer_EU_sales_out))
plot(total_timeser_consumer_EU_sales , col = "black")
lines(class_dec_pred_consumer_EU_sales, col = "red")



#So, that was classical decomposition, now let's do an ARIMA fit

autoarima_consumer_EU_sales <- auto.arima(timeser_sales_consumer_EU)
autoarima_consumer_EU_sales
tsdiag(autoarima_consumer_EU_sales)
plot(autoarima_consumer_EU_sales$x, col="black")
lines(fitted(autoarima_consumer_EU_sales), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima_consumer_EU_sales <- timeser_sales_consumer_EU  - fitted(autoarima_consumer_EU_sales)
auto.arima(resi_auto_arima_consumer_EU_sales)##Residue can be stationaery as ARIMA 0,0,0 model is obtained. 

adf.test(resi_auto_arima_consumer_EU_sales,alternative = "stationary")##P=0.01
kpss.test(resi_auto_arima_consumer_EU_sales)#p=0.1 confirming that residue is noise

#Also, let's evaluate the model using MAPE
fcast_auto_arima_consumer_EU_sales  <- predict(autoarima_consumer_EU_sales, n.ahead = 6)
#fcast_auto_arima <- forecast(autoarima, h=6)

autoarima_consumer_EU_sales <- data.frame(autoarima_consumer_EU_sales)

MAPE_auto_arima_consumer_EU_sales  <- accuracy(fcast_auto_arima_consumer_EU_sales$pred,outdata_consumer_EU_sales[,2])[5]
MAPE_auto_arima_consumer_EU_sales ##MAPE is 28

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit


auto_arima_pred_consumer_EU_sales <- c(fitted(autoarima_consumer_EU_sales),fcast_auto_arima_consumer_EU_sales$pred)
plot(total_timeser_consumer_EU_sales, col = "black")
lines(auto_arima_pred_consumer_EU_sales, col = "red")

#MAPE for ARIMA model is less so using it for prediction
##Predicting 6 monts future Sales for Consumer EU Sales

F6_autoarima_consumer_EU_sales <- auto.arima(total_timeser_consumer_EU_sales)


F6_autoarima_consumer_EU_sales <- predict(F6_autoarima_consumer_EU_sales, n.ahead = 6)

F6_autoarima_consumer_EU_sales<- data.frame(F6_autoarima_consumer_EU_sales$pred)


##Sales for next 6 months are predicted as 49358, 58063, 59714, 54191, 58811, 58010.
#--------------------------------------------------------------------------------------------------------------------------

##4## Creating time series for Corporate EMEA Quantity which is all except the last 6 months data

indata_consumer_EU <- Consumer_EU [1:42,]
total_timeser_consumer_EU_quant <- ts(Consumer_EU$Quantity)
timeser_consumer_EU_quant <- ts(indata_consumer_EU$Quantity)
plot(timeser_consumer_EU_quant)

detach(package:dplyr)

#Smoothing the series - Moving Average Smoothing

w <-1
smoothedseries_consumer_EU_quant <- filter(timeser_consumer_EU_quant, 
                                  filter=rep(1/(2*w+1),(2*w+1)), 
                                  method='convolution', sides=2)

#Smoothing left end of the time series

diff <- smoothedseries_consumer_EU_quant[w+2] - smoothedseries_consumer_EU_quant[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_consumer_EU_quant[i] <- smoothedseries_consumer_EU_quant[i+1] - diff
}

#Smoothing right end of the time series

n <- length(timeser_consumer_EU_quant)
diff <-  smoothedseries_consumer_EU_quant[n-w] -  smoothedseries_consumer_EU_quant[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_consumer_EU_quant[i] <-  smoothedseries_consumer_EU_quant[i-1] + diff
}

#Plot the smoothed time series
indata_consumer_EU$Month <- c(1:42)

timevals_consumer_EU <- indata_consumer_EU$Month
lines(smoothedseries_consumer_EU_quant, col="blue", lwd=2)


#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

smootheddf_consumer_EU_quant <- as.data.frame(cbind(timevals_consumer_EU, as.vector(smoothedseries_consumer_EU_quant)))
colnames(smootheddf_consumer_EU_quant) <- c('Month', 'Quantity')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit_consumer_EU_quant <- lm(Quantity ~ sin(0.4*Month)    * poly(Month,2.8)  + cos(0.4*Month) * poly(Month,2.8)
                     + Month, data=smootheddf_consumer_EU_quant)
global_pred_consumer_EU_quant <- predict(lmfit_consumer_EU_quant, Month=timevals_consumer_EU)
summary(global_pred_consumer_EU_quant)
lines(timevals_consumer_EU, global_pred_consumer_EU_quant, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

local_pred_consumer_EU_quant <- timeser_consumer_EU_quant -global_pred_consumer_EU_quant
plot(local_pred_consumer_EU_quant, col='red', type = "l")
acf(local_pred_consumer_EU_quant)
acf(local_pred_consumer_EU_quant, type="partial")
armafit_consumer_EU_qunat <- auto.arima(local_pred_consumer_EU_quant)

tsdiag(armafit_consumer_EU_qunat )
armafit_consumer_EU_qunat 

#We'll check if the residual series is white noise

resi_auto_arima_consumer_EU_qunat <- local_pred_consumer_EU_quant-fitted(armafit_consumer_EU_qunat)
auto.arima(resi_auto_arima_consumer_EU_qunat)##residue can be noise aas ARIMA 0,0,0 model obtained for residue

adf.test(resi_auto_arima_consumer_EU_qunat,alternative = "stationary")#p=0.01 which is less than 0.05
kpss.test(resi_auto_arima_consumer_EU_qunat)#p=0.1 indicating residue is noise

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months


outdata_consumer_EU_quant <- Consumer_EU[43:48,]
outdata_consumer_EU_quant$Month <- c(43:48)

timevals_consumer_out_qunat <- outdata_consumer_EU_quant$Month

outdata_consumer_EU_quant_out <- outdata_consumer_EU_quant[,2]
outdata_consumer_EU_quant_out <- cbind(timevals_consumer_out_qunat, outdata_consumer_EU_quant_out)

global_pred_consumer_EU_quantt_out <- predict(lmfit_consumer_EU_quant ,data.frame(Month =timevals_consumer_out_qunat))

fcast_consumer_EU_quant <- global_pred_consumer_EU_quantt_out

#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec_consumer_EU_quant <- accuracy(fcast_consumer_EU_quant,outdata_consumer_EU_quant_out[,2])[5]
MAPE_class_dec_consumer_EU_quant##MAPE is 98

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

class_dec_pred_consumer_EU_quant  <- c(ts(global_pred_consumer_EU_quant),ts(global_pred_consumer_EU_quantt_out))
plot(total_timeser_consumer_EU_quant, col = "black")
lines(class_dec_pred_consumer_EU_quant, col = "red")



#So, that was classical decomposition, now let's do an ARIMA fit

autoarima_consumer_EU_quant <- auto.arima(timeser_consumer_EU_quant )
autoarima_consumer_EU_quant
tsdiag(autoarima_consumer_EU_quant)
plot(autoarima_consumer_EU_quant$x, col="black")
lines(fitted(autoarima_consumer_EU_quant), col="red")

#Again, let's check if the residual series is white noise

resi_auto_arima_consumer_EU_qunat <- timeser_consumer_EU_quant - fitted(autoarima_consumer_EU_quant)
auto.arima(resi_auto_arima_consumer_EU_qunat)##can be noise as 0,0,0 model is obtained 
adf.test(resi_auto_arima_consumer_EU_qunat,alternative = "stationary")#p=0.04 less than 0.05
kpss.test(resi_auto_arima_consumer_EU_qunat)#p=0.1 indicating that residue is noise. 

#Also, let's evaluate the model using MAPE
fcast_auto_arima_consumer_EU_quant  <- predict(autoarima_consumer_EU_quant, n.ahead = 6)
#fcast_auto_arima <- forecast(autoarima, h=6)

fcast_auto_arima_consumer_EU_quant <- data.frame(fcast_auto_arima_consumer_EU_quant)

MAPE_auto_arima_consumer_EU_quant  <- accuracy(fcast_auto_arima_consumer_EU_quant$pred,outdata_consumer_EU_quant_out[,2])[5]
MAPE_auto_arima_consumer_EU_quant  #MAPE is 99

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit


auto_arima_pred_consumer_EU_quant <- c(fitted(autoarima_consumer_EU_quant),fcast_auto_arima_consumer_EU_quant$pred)
plot(total_timeser_consumer_EU_quant , col = "black")
lines(auto_arima_pred_consumer_EU_quant, col = "red")

##Mape is same, but visually classical decomposition looks better. 

##Predicting 6 monts future Quantity for corporate EMEA Quantity


F6_autoarima_consumer_EU_quantity <- auto.arima(total_timeser_consumer_EU_quant)


F6_autoarima_consumer_EU_quantity <- predict(F6_autoarima_consumer_EU_quantity, n.ahead = 6)

F6_autoarima_consumer_EU_quantity<- data.frame(F6_autoarima_consumer_EU_quantity$pred)
##NExt 6 months quantities are 626, 786, 842, 704, 768, 807.



