suppressWarnings(library(RODBC))

library(caret)
library(rpart)
library(rpart.plot)
library(rattle)
library(randomForest)
library(effects)
library(mosaic)
library(plotly)
library(tidyr)
library(reshape2)
library(corrplot)
library(lubridate)
library(scales)
library(pairsD3)
##Loading All Libraries
load.libraries <- c('data.table', 'gridExtra', 'corrplot', 'GGally', 'ggplot2', 'e1071', 'dplyr')
install.lib <- load.libraries[!load.libraries %in% installed.packages()]
for(libs in install.lib) install.packages(libs, dependences = TRUE)
sapply(load.libraries, require, character = TRUE)

##Load Loan data
loan_data <- read.csv("loan.csv",stringsAsFactors = FALSE,na.strings=c("NA","#DIV/0!", "","NaN"))
##Checking the Loan data
str(loan_data)
names(loan_data)
dim(loan_data)
table(loan_data$loan_status)
prop.table(table(loan_data$loan_status))
summary(loan_data)

loan_data$loan_status <- as.factor(loan_data$loan_status)

# Checking for dulpicate records- zero duplicate records
cat("The number of duplicate rows are ",nrow(loan_data)-nrow(unique(loan_data)))

#Checking for variables contaning NA values
NA.proportion <-  function(x) mean(is.na(x))

table(NA.proportion= round(sapply(loan_data,NA.proportion),2))
options(scipen = 2) 
colSums(is.na(loan_data))
colMeans(is.na(loan_data))

barchart(colMeans(is.na(loan_data)))
#Removing NA Values
loan_data <-  loan_data[,colMeans(is.na(loan_data)) <= 0.30]
#Removing near zero variance values
loan_data1 <- subset(loan_data,select = -c(loan_status))
ZC <-  nearZeroVar(loan_data1,saveMetrics = T);ZC

NZV<- which(ZC==T)

if(length(NZV) > 0) {
  loan_data1 <-  loan_data[,-(NZV)]
}else{
  message("No variables with near zero variance")
}

loan_data1$loan_status <- loan_data$loan_status
loan_data <- loan_data1

summary(loan_data)

library(VIM)
mice_plot <- aggr(loan_data[,-(dim(loan_data)[2])], col=c('navyblue','yellow'),
                  numbers=TRUE, sortVars=TRUE,
                  labels=names(loan_data[,-(dim(loan_data)[2])]), cex.axis=.7,
                  gap=3, ylab=c("Missing data","Pattern"))
options(scipen = 2) 
#mice plot gives information that there are still some mising data

#Removing variables contaning huge amont of zeros

zero.proportion <-  function(x) mean(x==0,na.rm=T)
table(zero.proportion=round(sapply(loan_data,zero.proportion),2))



loan_data_zero <- which(sapply(loan_data,zero.proportion)<=0.30)
loan_data<- loan_data[,loan_data_zero]
summary(loan_data)

#Removing variables contaning only unique value
unique_col <- function(x){
  if(length(unique(x))==1){
    unique(x)
  }
}
loan_data<- loan_data[,which(sapply(sapply(loan_data,unique_col),is.null))] 
summary(loan_data)
head(loan_data)

#Classifying variables based on customer demographic, customer information and loan payment behaviour
names(loan_data)
#Variables related to customer demographic
#emp_title,emp_length,home_ownership,annual_inc,verification_status,url,purpose,title,zip_code,addr_state

#Variables related to customer information
#loan_amnt,funded_amnt,funded_amnt_inv,term,int_rate,installment,grade,sub_grade,loan_status,issue_d,dti

#Variables related to customer payment behaviour
# earliest_cr_line,open_acc,revol_bal,revol_util,total_acc,total_pymnt,total_pymnt_inv,total_rec_prncp,total_rec_int,last_pymnt_d,last_pymnt_amnt,last_credit_pull_d

#Variables related to customer payment behaviour will not be relevant to EDA as
# payment information will not be available with the bank at the time it makes a decision of granting a loan.
#Hence, these variables can be dropped from the dataset and need not be analyzed.

# dropping the variable related to customer payment behaviour
loan_data <- subset(loan_data,select=-c(earliest_cr_line,open_acc,revol_bal,revol_util,total_acc,total_pymnt,total_pymnt_inv,total_rec_prncp,total_rec_int,last_pymnt_d,last_pymnt_amnt,last_credit_pull_d))

summary(loan_data)

#removing employee title,url and title from the DF as these variables are not significant for the analysis
loan_data <-subset(loan_data,select=-c(emp_title,url,title))


# Modifying employee length variable to numeric and making 10+ year as 10 year and less than 1 year as 0 year as given in data dictionary

 loan_data<- separate(loan_data,emp_length,c("emp_length"),sep="years|year")
 loan_data$emp_length<- ifelse(loan_data$emp_length=="10+ ", "10",ifelse(loan_data$emp_length=="< 1 ", "0",loan_data$emp_length))
 loan_data$emp_length <- as.numeric(loan_data$emp_length)
 

loan_data$emp_length[is.na(loan_data$emp_length)]<-0



# Making interest rate as numeric column by removing % sign for analysis
loan_data <- separate(loan_data,int_rate,c("int_rate"),sep="%")
loan_data$int_rate <-  as.numeric(loan_data$int_rate)
summary(loan_data$int_rate)



# Deriving issue year variable form issue date variable
loan_data$issue_year <- year(as.Date(paste("01-",loan_data$issue_d,sep = ''),format = "%d-%b-%y"))
#removing issue date
loan_data <-subset(loan_data,select=-c(issue_d))


# Creating bin variable for DTI
summary(loan_data$dti)
loan_data$DTI_Bin <- ifelse(loan_data$dti<=10,"Low_DTI",ifelse(loan_data$dti>10 & loan_data$dti <=20,"medium_dti","high_dti"))
loan_data_defaulters <- loan_data %>% filter(loan_status=="Charged Off")

loan_data %>% ggplot(aes(x = as.factor(loan_status))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "loan status distribution", y = "Percent", x = "loan status")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 
#14 % are defaulters
#Univariate analysis

# Dividing variables into categorical and numerical variable
cat_var <- names(loan_data)[which(sapply(loan_data,is.character))]
cat_var
num_var <- names(loan_data)[which(sapply(loan_data,is.numeric))]
num_var

#boxplot of numerical variables
ggplot(melt(loan_data),aes(x=variable, y=value,color=loan_status))+geom_boxplot()
#Analysis- Annual income have high number of outliers

#univariate on categorical variables

#Univariate on term
ggplot(loan_data, aes(x=term,fill=loan_status)) + geom_histogram(stat="count",position = "dodge")
#considering overall histogram 36 month term is well suited for fully paid customers
loan_data_term <- loan_data %>% filter(loan_status=="Charged Off")
#Analysing proportions of term only for defaulters
prop.table(table(loan_data_term$loan_status,loan_data_term$term))
#57 % are defaulters for 36 month term and 43 % are defaulters of 60 month term out of total defaulters
#              36 months  60 months
#Charged Off   0.573485   0.426515
#Current       0.000000   0.000000
#Fully Paid    0.000000   0.000000

#Univariate on grade
loan_data%>% filter(loan_status=="Charged Off") %>% ggplot(aes(x = as.factor(grade))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "grade distribution for defaulters", y = "Percent", x = "grade")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#B,C,D are having nearly most number of defaulters, combining 60% of defaulters

#Univariate on sub grade
loan_data%>% filter(loan_status=="Charged Off") %>% ggplot( aes(x=sub_grade)) + geom_histogram(stat="count")
#B3 ~C2,D2~E1 are having nearly most number of defaulters

#Univariate on home_ownership
loan_data%>% filter(loan_status=="Charged Off") %>% ggplot(aes(x = as.factor(home_ownership))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "home owner ship distribution for defaulters", y = "Percent", x = "home owner ship")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
)

#Rent is having most number of defaulters ,next is Mortgage

#Univariate on verification_status
ggplot(loan_data, aes(x=verification_status,fill=loan_status)) + geom_histogram(stat="count",position = "dodge")
loan_data%>% filter(loan_status=="Charged Off") %>% ggplot( aes(x=verification_status)) + geom_histogram(stat="count")
#Verification status doesn't give clear picture

#Univariate on purpose

loan_data%>% filter(loan_status=="Charged Off") %>% ggplot(aes(x = as.factor(purpose))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "purpose distribution for defaulters", y = "Percent", x = "purpose")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
)
#debt_consolidation is having most number of defaulters covering around 50% of over all defaulters

#Univariate on zip_code
ggplot(loan_data, aes(x=zip_code,fill=loan_status)) + geom_histogram(stat="count")
loan_data%>% filter(loan_status=="Charged Off") %>% ggplot( aes(x=zip_code)) + geom_histogram(stat="count")
#We can ignore zip_code as it doesn't give proper picture

#Univariate on addr_state


loan_data%>% filter(loan_status=="Charged Off") %>% ggplot(aes(x = as.factor(addr_state))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "State distribution for defaulters", y = "Percent", x = "State")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
)
#CA is having most number of defaulters,20% of overall defaulters



#Univariate on int_rate

ggplot(loan_data, aes(x=1:nrow(loan_data), y=int_rate, color=loan_status)) + geom_point() + geom_line() + xlab("rows")
#Int rate more than 15% is having more defaulters

#Univariate on loan_amnt
ggplot(loan_data, aes(x=1:nrow(loan_data), y=loan_amnt, color=loan_status)) + geom_point() + xlab("rows") 
# As per above graph, Loan amount is distiuted all over as per loan status, so can conclude that it doesnot have any impact on bad loans


ggplot(loan_data, aes(x=loan_status,y=loan_amnt,group=loan_status)) + geom_boxplot()




#Univariate on funded_amnt
ggplot(loan_data, aes(x=1:nrow(loan_data), y=funded_amnt, color=loan_status)) + geom_point() + xlab("rows") 

# As per above graph, Funded amount is distiuted all over as per loan status, so can conclude that it doesnot have any impact on bad loans

#univariate on funded_amnt_inv
ggplot(loan_data, aes(x=1:nrow(loan_data), y=funded_amnt_inv, color=loan_status)) + geom_point() + xlab("rows") 
# As per above graph, Funded amount inv is distiuted all over as per loan status, so can conclude that it doesnot have any impact on bad loans

#univariate on Installment
ggplot(loan_data, aes(x=1:nrow(loan_data), y=installment, color=loan_status)) + geom_point() + xlab("rows") 
loan_data%>% filter(loan_status=="Charged Off")%>%ggplot( aes(x=installment)) + geom_histogram(stat="count")
# As per above graph, Installment is distiuted all over as per loan status, so can conclude that it doesnot have any impact on loan status 
#but the second graph shows that instllment < 500 constitutes chunk of bad loans

#univariate on employee length
loan_data%>% filter(loan_status=="Charged Off") %>% ggplot(aes(x = as.factor(emp_length))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "Employment length distribution for defaulters", y = "Percent", x = "Employment length")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
)

# Above Graph shows that employee having 10 and more years of Experiece have more bad loans,and next is employee having less than 1 year of exp.

#univariate on Annual income
ggplot(loan_data, aes(x=1:nrow(loan_data), y=annual_inc, color=loan_status)) + geom_point() + xlab("rows") 

#Segmented Analysis Anual Income - creatig new variable annual_inc_bin
loan_data$annual_inc_bin <- ifelse(loan_data$`annual_inc`>=0 & loan_data$`annual_inc`<30000,"0-30000",ifelse(loan_data$`annual_inc`>=30000 & loan_data$`annual_inc`<60000,"30000-60000",ifelse(loan_data$`annual_inc`>=60000 & loan_data$`annual_inc`<90000,"60000-90000",ifelse(loan_data$`annual_inc`>=90000 & loan_data$`annual_inc`<120000,"90000-120000", ifelse(loan_data$`annual_inc`>=120000 & loan_data$`annual_inc`<1500000,"120000-150000", ifelse(loan_data$`annual_inc`>=150000 & loan_data$`annual_inc`<180000,"150000-180000", ">180000"))))))
loan_data%>% filter(loan_status=="Charged Off")%>%ggplot( aes(x=annual_inc_bin)) + geom_histogram(stat="count")
#Above plot shows that employee having annual income 30K-60K have bad loans


#univariate on DTI
loan_data%>% filter(loan_status=="Charged Off")%>%ggplot( aes(x=DTI_Bin)) + geom_histogram(stat="count")
#- Medium DTI i.e DTI ratio b/w 11 and 20 have high chances of loan defaults



#univariate on issue_year

loan_data%>% filter(loan_status=="Charged Off")%>%ggplot( aes(x=issue_year)) + geom_histogram()
#Year on year loan defaulters are increasing 

#Removing variables not used for analysis
loan_data <-subset(loan_data,select=-c(zip_code))

#Reassigning categorical and numerical variable
cat_var <- names(loan_data)[which(sapply(loan_data,is.character))]
cat_var
num_var <- names(loan_data)[which(sapply(loan_data,is.numeric))]
num_var
#Bivariate Analysis
 pairs(loan_data[,c("loan_amnt","funded_amnt","funded_amnt_inv","installment")],col=loan_data$loan_status)



 # Finding the correlation between numeric variables
 num <- which(sapply(loan_data,is.numeric))
 corMTX <- cor(data.frame(loan_data[,num]))
 corrplot(corMTX, method = "number", type = "lower", order = "FPC", tl.cex=0.6 )
 diag(corMTX) <- 0 
 plot( levelplot(corMTX, 
                 main ="Correlation matrix",
                 scales=list(x=list(rot=90), cex=1.0)))
 
 corrplot(corMTX, method="number")
 # from the graph loan amount, funded amt ,funded_amnt_inv and installment are highly corelated, removing  funded amt ,funded_amnt_inv and installment variables,which is ovious as  funded amt ,funded_amnt_inv and installment are dependent on loan amount
loan_data <-subset(loan_data,select=-c(funded_amnt,funded_amnt_inv,installment))



#loan amount based on the purpose
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=loan_amnt)) + geom_line(stat = 'density',color='green')+facet_wrap(~purpose)+ggtitle("Loan Amount Vs Purpose")+xlab("Loan Distribution")
#Loan amount 10000 or less and taken for car,vacation and movement purpose are bad loans 

#loan amount based on the grade
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=loan_amnt)) + geom_line(stat = 'density',color='green')+facet_wrap(~grade)+ggtitle("Loan Amount vs grade")+xlab("Loan Distribution")
#Loan amount 10000 and for grade A are bad loans

#loan amount based on verification status
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=loan_amnt)) + geom_line(stat = 'density',color='green')+facet_wrap(~verification_status)+ggtitle("Loan Amount vs Verification status")+xlab("Loan Distribution")
# Not Verified loan amount <10K are more prone to charged off

#loan amount on home ownership
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=loan_amnt)) + geom_line(stat = 'density',color='green')+facet_wrap(~home_ownership)+ggtitle("Loan amt vs home ownership")+xlab("Loan amt based on emp length")
#Loan amount 10K or less and for Rent are bad loans

#interest rate on the purpose
# Making interest rate as numeric column by removing % sign for analysis
loan_data <- separate(loan_data,int_rate,c("int_rate"),sep="%")
loan_data$int_rate <-  as.numeric(loan_data$int_rate)
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=int_rate)) + geom_line(stat = 'density',color='green')+facet_wrap(~purpose)+ggtitle("Interest rate   Distribution on purpose")+xlab("Interest rate  Distribution")
#For all the purpose 10-15% interest rate goes for defaulters



#Annual income on grade
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=annual_inc)) + geom_line(stat = 'density',color='green')+facet_wrap(~grade)+ggtitle("Annual Income Distribution  on grade")+xlab("Annual Income  Distribution")
#For All grade Annual Income <200,000 goes for defaulters

# Annual income vs purpose
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=annual_inc)) + geom_line(stat = 'density',color='green')+facet_wrap(~purpose)+ggtitle("Annual Income Distribution  on purpose")+xlab("Annual Income  Distribution")
#For All purpose Annual Income <200,000 goes for defaulters

#Interest rate on home_ownership
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=int_rate)) + geom_line(stat = 'density',color='green')+facet_wrap(~home_ownership)+ggtitle("Interest rate distribution on home ownership")+xlab("Interest rate  Distribution")
#For All home ownership type 10-15% interest rate are for charged off loans

#year based vs purpose of loan
loan_data %>% filter(loan_status=="Charged Off") %>% ggplot( aes(x=issue_year,fill=factor(purpose))) + geom_bar(position = "dodge",stat = "count")
#Every year  debt consolidation consitutes major part of bad loan and it is increasing on higher rate year on year

#emp length vs purpose

loan_data %>% filter(loan_status=="Charged Off") %>% ggplot( aes(x=emp_length,fill=factor(purpose))) + geom_bar(position = "dodge",stat = "count")
#Employment length 10 or 10+ year consitues majority of bad loan with debt consolidation as a purpose

#DTI vs Purpose
loan_data %>%filter(loan_status=="Charged Off")%>% ggplot(aes(x=dti)) + geom_line(stat = 'density',color='green')+facet_wrap(~purpose)+ggtitle("DTI distribution on purpose")+xlab("DTI  Distribution")
# DTI ratio between 10 to 20 have high chances of loan defaults for all purpose




## Final Conclusion

# Drivable variables for loan default
#1. Grade
#2. Home ownership- Rent
#3. Purpose - Debt COnsolidation
#4 Interset rate- 10-15%
#5 Employee length- 10+
#6.Annual Income - <200,000
#7Loan amount <- 10000

names(loan_data)
#[1] "loan_amnt"           "term"                "int_rate"            "grade"               "sub_grade"           "emp_length"         
#[7] "home_ownership"      "annual_inc"          "verification_status" "loan_status"         "purpose"             "addr_state"         
#[13] "dti"
#These variables will be used for further modeling


