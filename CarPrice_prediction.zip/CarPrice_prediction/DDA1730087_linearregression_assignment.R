#loading libraries
library(caret)
library(rpart)
library(rpart.plot)
library(rattle)
library(randomForest)
library(effects)
library(mosaic)
library(plotly)
library(tidyr)
library(reshape2)
library(corrplot)
library(lubridate)
library(scales)
library(pairsD3)
library(MASS)
library(car)
##Loading All Libraries
load.libraries <- c('data.table', 'gridExtra', 'corrplot', 'GGally', 'ggplot2', 'e1071', 'dplyr')
install.lib <- load.libraries[!load.libraries %in% installed.packages()]
for(libs in install.lib) install.packages(libs, dependences = TRUE)
sapply(load.libraries, require, character = TRUE)

#Loading car price data
car <- read.csv("CarPrice_Assignment.csv",stringsAsFactors = FALSE)
View(car)
str(car)

# Checking for dulpicate records- zero duplicate records
cat("The number of duplicate rows are ",nrow(car)-nrow(unique(car)))

#Checking for variables contaning NA values
NA.proportion <-  function(x) mean(is.na(x))
# No Na values are present in any variables
table(NA.proportion= round(sapply(car,NA.proportion),2))

#seperating CarName variable to CarCompany and CarModel
car <-  separate(car,CarName,c("CarCompany","CarModel"),sep = " ")
str(car)

#checking redundancy in carCompany
summary(factor(car$CarCompany))
#By looking into carCompany variable have redundancies
# correcting the redundancies
#maxda and mazda are same - correcting to mazda
car$CarCompany[which(car$CarCompany %in% c("maxda","mazda"))] <- "mazda"

#nissan
car$CarCompany[which(car$CarCompany %in% c("nissan","Nissan"))] <- "nissan"

#porsche
car$CarCompany[which(car$CarCompany %in% c("porcshce","porsche"))] <- "porsche"

#toyota
car$CarCompany[which(car$CarCompany %in% c("toyouta","toyota"))] <- "toyota"

#volkswagen
car$CarCompany[which(car$CarCompany %in% c("vokswagen","volkswagen","vw"))] <- "volkswagen"
#Removing Car_ID and CarModel as it will not be used for the prediction of price of car
car <- subset(car,select = -c(car_ID,CarModel))
#symboling repesents risk value of car from +3 to -3 , +3 being risky and -3 being safe, So converting symboling into factor
car$symboling <- as.factor(car$symboling)
str(car)

#Performing EDA
#boxplot of numerical variables
ggplot(melt(car),aes(x=variable, y=value))+geom_boxplot()
#looking at the box plot , there is no significant outlier except price. But price is a dependent variable so no outlier treatment is required
summary(car)
#univariate on car company- toyota is having significantly more count than other car company
car%>%  ggplot(aes(x = as.factor(CarCompany))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "car company  distribution", y = "Percent", x = "car Company")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#univariate on fuel type- 90% of the data set is using gas fuel type and 10% is using diesel fuel
car%>%  ggplot(aes(x = as.factor(fueltype))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "fuel type  distribution", y = "Percent", x = "fuel type")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#univariate on aspiration-82% is using std and 18 % is using turbo
car%>%  ggplot(aes(x = as.factor(aspiration))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "aspiration  distribution", y = "Percent", x = "aspiration")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#univariate on doornumber- 56 % is using four doornumber and 44% is using two doornumber
car%>%  ggplot(aes(x = as.factor(doornumber))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "doornumber  distribution", y = "Percent", x = "doornumber")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#univariate on carbody- dedan and hatchback are significant carbody
car%>%  ggplot(aes(x = as.factor(carbody))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "carbody  distribution", y = "Percent", x = "carbody")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#Univariate on drivewheel- fwd and rwd are more significant drivewheel
car%>%  ggplot(aes(x = as.factor(drivewheel))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "drivewheel  distribution", y = "Percent", x = "drivewheel")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#univariate on enginelocation- 98% front  engine location and 2 % rear engine location
car%>%  ggplot(aes(x = as.factor(enginelocation))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "enginelocation  distribution", y = "Percent", x = "enginelocation")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 



#univariate on cylindernumber- frequency of four cylinder number are more than other cylinder number
car%>%  ggplot(aes(x = as.factor(cylindernumber))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "cylindernumber  distribution", y = "Percent", x = "cylindernumber")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#univariate on enginetype- frequency of ohc engine type  are more than other engine type
car%>%  ggplot(aes(x = as.factor(enginetype))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "enginetype  distribution", y = "Percent", x = "enginetype")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 

#univariate on fuelsystem- frequency of mpfl and 2bbl are more than others
car%>%  ggplot(aes(x = as.factor(fuelsystem))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "fuelsystem  distribution", y = "Percent", x = "fuelsystem")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 
# univariate of symboling - represents risk nature of car- All values are significant
car%>%  ggplot(aes(x = as.factor(symboling))) +geom_bar(aes(y = (..count..)/sum(..count..))) +geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +scale_y_continuous(labels = percent) +labs(title = "symboling  distribution", y = "Percent", x = "symboling")+theme(
  axis.text.y=element_blank(), axis.ticks=element_blank(),
  axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
) 


cat_var <- names(car)[which(sapply(car,is.character))]
cat_var
num_var<- names(car)[which(sapply(car,is.numeric))]
num_var


# Finding the correlation between numeric variables
num <- which(sapply(car,is.numeric))
corMTX <- cor(data.frame(car[,num]))
corrplot(corMTX, method = "number", type = "lower", order = "FPC", tl.cex=0.6 )
diag(corMTX) <- 0 
plot( levelplot(corMTX, 
                main ="Correlation matrix",
                scales=list(x=list(rot=90), cex=1.0)))

corrplot(corMTX, method="number")
# city mileage and highway mileage are very highly correlated which is correct, so keeping city mileage to for prediction
#car <- subset(car,select = -highwaympg)

#price of car based on CarCompany
ggplot(car, aes(x=CarCompany, y=price)) + geom_point() + xlab("Car Company")
#bmw,buick,jaguar,porsche prices are significantly higher than other car company indicating they are premium cars

#price of car based on fuel type
ggplot(car, aes(x=fueltype, y=price)) + geom_point() + xlab("Fuel Type")
#Some of the cars having fuel as gas have higher prices than diesel but 90% of data set is having gas as fuel type

#price of car based on aspiration
ggplot(car, aes(x=aspiration, y=price)) + geom_point() + xlab("aspiration")
#Some of the cars having aspiration as std have higher prices than turbo but 82% of data set is having std as aspiration

#price of car based on door number
ggplot(car, aes(x=doornumber, y=price)) + geom_point() + xlab("doornumber")
#door number doesn't have any significance on price

##price of car based on carbody
ggplot(car, aes(x=carbody, y=price)) + geom_point() + xlab("carbody")
#some of the cars having sedan body is having higher price

##price of car based on drivewheel
ggplot(car, aes(x=drivewheel, y=price)) + geom_point() + xlab("drivewheel")
#car haing rwd drivewheel is having higher price than other two


##price of car based on enginetype
ggplot(car, aes(x=enginetype, y=price)) + geom_point() + xlab("enginetype")
#enginetype is not significatnt for price

##price of car based on cylindernumber
ggplot(car, aes(x=cylindernumber, y=price)) + geom_point() + xlab("cylindernumber")
#eight cylinder number is high priced than others


##price of car based on fuelsystem
ggplot(car, aes(x=fuelsystem, y=price)) + geom_point() + xlab("fuelsystem")
#some of mpfi fuel system car is high priced than others

#price of car based on symboling
ggplot(car, aes(x=symboling, y=price)) + geom_point() + xlab("symboling")
#symboling doen't have much influence on price

summary(factor(car$CarCompany))
#Looking into the source of data set https://archive.ics.uci.edu/ml/datasets/Automobile, all other character variables can be converted into the 
#factor variables


for(i in 1:ncol(car)){
  if(is.character(car[,i])){
    car[,i] <- as.factor(car[,i])
  }
}
str(car)

#finding the factor variable having 2 levels
level_2_variable <- vector("character")
j <- 1
for(i in 1:ncol(car)){
  if(is.factor(car[,i])){
    if(length(levels(car[,i]))==2){
      
      level_2_variable[j] <- colnames(car)[i]
      j <- j+1
    }
  }
}
str(car)
level_2_variable
# variables having 2 levels
#"fueltype"       "aspiration"     "doornumber"     "enginelocation"

#Looking the structure of each variable and converting into numeric form by replacing with 0's and 1's
#fueltype
str(car$fueltype)
summary(factor(car$fueltype))
#diesel    gas 
#20    185

#replacing diesel with 0 and gas with 1
levels(car$fueltype)<-c(0,1)

# Now store the numeric values in the same variable
car$fueltype<- as.numeric(levels(car$fueltype))[car$fueltype]

#aspiration
str(car$aspiration)
summary(factor(car$aspiration))
#std turbo 
#168    37
#replacing std with 1 and turbo with 0
levels(car$aspiration)<-c(1,0)

# Now store the numeric values in the same variable
car$aspiration<- as.numeric(levels(car$aspiration))[car$aspiration]


#doornumber
str(car$doornumber)
summary(factor(car$doornumber))
#four  two
#115   90 
#replacing four with 1 and two with 0
levels(car$doornumber)<-c(1,0)

# Now store the numeric values in the same variable
car$doornumber<- as.numeric(levels(car$doornumber))[car$doornumber]

#enginelocation
str(car$enginelocation)
summary(factor(car$enginelocation))
#front  rear
#202     3 
#replacing four with 1 and two with 0
levels(car$enginelocation)<-c(1,0)

# Now store the numeric values in the same variable
car$enginelocation<- as.numeric(levels(car$enginelocation))[car$enginelocation]




str(car)

# converting variable with more than 3 level into numeric
#drivewheel
dummy_drivewheel <- data.frame(model.matrix(~drivewheel,data = car))
View(dummy_drivewheel)
dummy_drivewheel <- dummy_drivewheel[,-1]
#removing original drivewheel varible and combining into the original data frame
car_1 <- cbind(car[,-7],dummy_drivewheel)
str(car_1)

#carbody
dummy_carbody <- data.frame(model.matrix(~carbody,data = car_1))
View(dummy_carbody)
dummy_carbody <- dummy_carbody[,-1]
#removing original drivewheel varible and combining into the car_1 data frame
car_1<- cbind(car_1[,-6],dummy_carbody)
str(car_1)

#enginetype
dummy_enginetype <- data.frame(model.matrix(~ enginetype,data = car_1))
View(dummy_enginetype)

dummy_enginetype <- dummy_enginetype[,-1]
car_1 <- cbind(car_1[,-12],dummy_enginetype)
str(car_1)


#cylindernumber
dummy_cylindernumber <- data.frame(model.matrix(~ cylindernumber,data = car_1))
View(dummy_cylindernumber)
dummy_cylindernumber <- dummy_cylindernumber[,-1]
car_1 <- cbind(car_1[,-12],dummy_cylindernumber)
str(car_1)

#fuelsystem
dummy_fuelsystem <- data.frame(model.matrix(~fuelsystem,data=car_1))
View(dummy_fuelsystem)
dummy_fuelsystem <- dummy_fuelsystem[,-1]
car_1 <- cbind(car_1[,-13],dummy_fuelsystem)
str(car_1)

#symboling repesents risk value of car from +3 to -3 , +3 being risky and -3 being safe, So converting symboling into factor

dummy_symboling <- data.frame(model.matrix(~symboling,data=car_1))
View(dummy_symboling)
dummy_symboling <- dummy_symboling[,-1]
car_1 <- cbind(car_1[,-1],dummy_symboling)


str(car_1)
#CarCompany
dummy_CarCompany <- data.frame(model.matrix(~CarCompany,data = car_1))
View(dummy_CarCompany)
dummy_CarCompany <- dummy_CarCompany[,-1]
car_1 <- cbind(car_1[,-1],dummy_CarCompany)
str(car_1)

# Model Building
# separate train and test data
set.seed(100)
trainindices= sample(1:nrow(car_1), 0.7*nrow(car_1))
train = car_1[trainindices,]
test = car_1[-trainindices,]

#model1
model1_car <- lm(price ~.,data = train)
summary(model1_car)
#Residual standard error: 1436 on 83 degrees of freedom
#Multiple R-squared:  0.9819,	Adjusted R-squared:  0.9691 
#F-statistic: 76.48 on 59 and 83 DF,  p-value: < 2.2e-16

#performing stepAIC
step_car <- stepAIC(model1_car, direction="both")
step_car

#model2
model2_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                   curbweight + enginesize + stroke + peakrpm + drivewheelrwd + 
                   carbodyhardtop + carbodyhatchback + carbodysedan + carbodywagon + 
                   enginetypedohcv + enginetypel + enginetypeohc + enginetypeohcf + 
                   enginetyperotor + cylindernumberfive + cylindernumberthree + 
                   fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                   CarCompanybmw + CarCompanybuick + CarCompanydodge + CarCompanyhonda + 
                   CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                   CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                   CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                 data = train)
summary(model2_car)
#Residual standard error: 1329 on 105 degrees of freedom
#Multiple R-squared:  0.9804,	Adjusted R-squared:  0.9735 
#F-statistic: 142.2 on 37 and 105 DF,  p-value: < 2.2e-16

vif(model2_car)

#removing curbweight as having very high VIF

#model3
model3_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                   enginesize + stroke + peakrpm + drivewheelrwd + 
                   carbodyhardtop + carbodyhatchback + carbodysedan + carbodywagon + 
                   enginetypedohcv + enginetypel + enginetypeohc + enginetypeohcf + 
                   enginetyperotor + cylindernumberfive + cylindernumberthree + 
                   fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                   CarCompanybmw + CarCompanybuick + CarCompanydodge + CarCompanyhonda + 
                   CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                   CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                   CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                 data = train)
summary(model3_car)
# Residual standard error: 1381 on 106 degrees of freedom
#Multiple R-squared:  0.9787,	Adjusted R-squared:  0.9714 
#F-statistic: 135.1 on 36 and 106 DF,  p-value: < 2.2e-16#

#checking vif on model3
vif(model3_car)

#removing carbodysedan from next model as having high VIF

#model4
model4_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                   enginesize + stroke + peakrpm + drivewheelrwd + carbodyhardtop + 
                   carbodyhatchback +  carbodywagon + enginetypedohcv + 
                   enginetypel + enginetypeohc + enginetypeohcf + enginetyperotor + 
                   cylindernumberfive + cylindernumberthree + fuelsystem2bbl + 
                   symboling.1 + symboling0 + symboling3 + CarCompanybmw + CarCompanybuick + 
                   CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                   CarCompanymercury + CarCompanymitsubishi + CarCompanynissan + 
                   CarCompanyplymouth + CarCompanyrenault + CarCompanysaab + 
                   CarCompanytoyota + CarCompanyvolkswagen, data = train)

summary(model4_car)

#Residual standard error: 1428 on 107 degrees of freedom
#Multiple R-squared:  0.977,	Adjusted R-squared:  0.9695 
#F-statistic: 129.8 on 35 and 107 DF,  p-value: < 2.2e-16

#checking vif om model4
vif(model4_car)
#removing enginesize as it is having VIF more than 10

#model5
model5_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                   stroke + peakrpm + drivewheelrwd + carbodyhardtop + 
                   carbodyhatchback + carbodywagon + enginetypedohcv + enginetypel + 
                   enginetypeohc + enginetypeohcf + enginetyperotor + cylindernumberfive + 
                   cylindernumberthree + fuelsystem2bbl + symboling.1 + symboling0 + 
                   symboling3 + CarCompanybmw + CarCompanybuick + CarCompanydodge + 
                   CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                   CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                   CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                 data = train)

summary(model5_car)
#Residual standard error: 1895 on 108 degrees of freedom
#Multiple R-squared:  0.9591,	Adjusted R-squared:  0.9462 
#F-statistic: 74.41 on 34 and 108 DF,  p-value: < 2.2e-16





#checking vif on model5
vif(model5_car)

# drivewheelrwd is having h pvalue and high vif,removing drivewheelrwd 

model6_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                   stroke + peakrpm +  carbodyhardtop + carbodyhatchback + 
                   carbodywagon + enginetypedohcv + enginetypel + enginetypeohc + 
                   enginetypeohcf + enginetyperotor + cylindernumberfive + cylindernumberthree + 
                   fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                   CarCompanybmw + CarCompanybuick + CarCompanydodge + CarCompanyhonda + 
                   CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                   CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                   CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                 data = train)


summary(model6_car)
#Residual standard error: 1896 on 109 degrees of freedom
#Multiple R-squared:  0.9587,	Adjusted R-squared:  0.9462 
#F-statistic: 76.62 on 33 and 109 DF,  p-value: < 2.2e-16

#checking vif on model6

vif(model6_car)
#now all the variables are having VIF less than 5 , so removing variable based on HIgh VIF and p value >0.05
#removing stroke from next model  

model7_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                   peakrpm + carbodyhardtop + carbodyhatchback + carbodywagon + 
                   enginetypedohcv + enginetypel + enginetypeohc + enginetypeohcf + 
                   enginetyperotor + cylindernumberfive + cylindernumberthree + 
                   fuelsystem2bbl + symboling.1 + symboling0 + symboling3 + 
                   CarCompanybmw + CarCompanybuick + CarCompanydodge + CarCompanyhonda + 
                   CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                   CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                   CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                 data = train)

summary(model7_car)
#Residual standard error: 1887 on 110 degrees of freedom
#Multiple R-squared:  0.9587,	Adjusted R-squared:  0.9466 
#F-statistic: 79.73 on 32 and 110 DF,  p-value: < 2.2e-16

# checking vif on model7
vif(model7_car)
#fuelsystem2bbl
#removing fuelsystem2bbl from next model


model8_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                   peakrpm + carbodyhardtop + carbodyhatchback + carbodywagon + 
                   enginetypedohcv + enginetypel + enginetypeohc + enginetypeohcf + 
                   enginetyperotor + cylindernumberfive + cylindernumberthree + 
                   symboling.1 + symboling0 + symboling3 + 
                   CarCompanybmw + CarCompanybuick + CarCompanydodge + CarCompanyhonda + 
                   CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                   CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                   CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                 data = train)
summary(model8_car)

#Residual standard error: 1880 on 111 degrees of freedom
#Multiple R-squared:  0.9586,	Adjusted R-squared:  0.947 
#F-statistic: 82.91 on 31 and 111 DF,  p-value: < 2.2e-16

#checking vif on model8
vif(model8_car)
#removing peakrpm as high p value 

model9_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                   carbodyhardtop + carbodyhatchback + carbodywagon + 
                   enginetypedohcv + enginetypel + enginetypeohc + enginetypeohcf + 
                   enginetyperotor + cylindernumberfive + cylindernumberthree + 
                   symboling.1 + symboling0 + symboling3 + CarCompanybmw + CarCompanybuick + 
                   CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                   CarCompanymercury + CarCompanymitsubishi + CarCompanynissan + 
                   CarCompanyplymouth + CarCompanyrenault + CarCompanysaab + 
                   CarCompanytoyota + CarCompanyvolkswagen, data = train)
summary(model9_car)
#Residual standard error: 1877 on 112 degrees of freedom
#Multiple R-squared:  0.9584,	Adjusted R-squared:  0.9472 
#F-statistic: 85.94 on 30 and 112 DF,  p-value: < 2.2e-16

# checking vif on model9
vif(model9_car)

#removing symboling3 from next model

model10_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    carbodyhardtop + carbodyhatchback + carbodywagon + enginetypedohcv + 
                    enginetypel + enginetypeohc + enginetypeohcf + enginetyperotor + 
                    cylindernumberfive + cylindernumberthree + symboling.1 + 
                    symboling0 +  CarCompanybmw + CarCompanybuick + 
                    CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                    CarCompanymercury + CarCompanymitsubishi + CarCompanynissan + 
                    CarCompanyplymouth + CarCompanyrenault + CarCompanysaab + 
                    CarCompanytoyota + CarCompanyvolkswagen, data = train)
summary(model10_car)
#Residual standard error: 1877 on 113 degrees of freedom
#Multiple R-squared:  0.958,	Adjusted R-squared:  0.9472 
#F-statistic: 88.83 on 29 and 113 DF,  p-value: < 2.2e-16


#checking vif on model10
vif(model10_car)

#removing carbodywagon  from next model

model11_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    carbodyhardtop + carbodyhatchback +  enginetypedohcv + 
                    enginetypel + enginetypeohc + enginetypeohcf + enginetyperotor + 
                    cylindernumberfive + cylindernumberthree + symboling.1 + 
                    symboling0 + CarCompanybmw + CarCompanybuick + CarCompanydodge + 
                    CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                    CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                    CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                  data = train)
summary(model11_car)
#Residual standard error: 1869 on 114 degrees of freedom
#Multiple R-squared:  0.958,	Adjusted R-squared:  0.9476 
#F-statistic:  92.8 on 28 and 114 DF,  p-value: < 2.2e-16

#checking vif on model11
vif(model11_car)

#removing carbodyhardtop in next model

model12_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    carbodyhatchback + enginetypedohcv + enginetypel + 
                    enginetypeohc + enginetypeohcf + enginetyperotor + cylindernumberfive + 
                    cylindernumberthree + symboling.1 + symboling0 + CarCompanybmw + 
                    CarCompanybuick + CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + 
                    CarCompanymazda + CarCompanymercury + CarCompanymitsubishi + 
                    CarCompanynissan + CarCompanyplymouth + CarCompanyrenault + 
                    CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                  data = train)
summary(model12_car)
#Residual standard error: 1861 on 115 degrees of freedom
#Multiple R-squared:  0.958,	Adjusted R-squared:  0.9481 
#F-statistic: 97.05 on 27 and 115 DF,  p-value: < 2.2e-16


#checking vif on model12
vif(model12_car)

#removing enginetypedohcv from next model

#model13
model13_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    carbodyhatchback +  enginetypel + enginetypeohc + 
                    enginetypeohcf + enginetyperotor + cylindernumberfive + cylindernumberthree + 
                    symboling.1 + symboling0 + CarCompanybmw + CarCompanybuick + 
                    CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                    CarCompanymercury + CarCompanymitsubishi + CarCompanynissan + 
                    CarCompanyplymouth + CarCompanyrenault + CarCompanysaab + 
                    CarCompanytoyota + CarCompanyvolkswagen, data = train)
summary(model13_car)
#Residual standard error: 1856 on 116 degrees of freedom
#Multiple R-squared:  0.9578,	Adjusted R-squared:  0.9484 
#F-statistic: 101.3 on 26 and 116 DF,  p-value: < 2.2e-16

#vif on model13

vif(model13_car)

#  removing symboling0 from next as having highest p value

#model14
model14_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    carbodyhatchback + enginetypel + enginetypeohc + enginetypeohcf + 
                    enginetyperotor + cylindernumberfive + cylindernumberthree + 
                    symboling.1 +  CarCompanybmw + CarCompanybuick + 
                    CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                    CarCompanymercury + CarCompanymitsubishi + CarCompanynissan + 
                    CarCompanyplymouth + CarCompanyrenault + CarCompanysaab + 
                    CarCompanytoyota + CarCompanyvolkswagen, data = train)

summary(model14_car)
#Residual standard error: 1854 on 117 degrees of freedom
#Multiple R-squared:  0.9575,	Adjusted R-squared:  0.9485 
#F-statistic: 105.6 on 25 and 117 DF,  p-value: < 2.2e-16


#vif on model14
vif(model14_car)
#enginetyperotor is having highest p value
#removing enginetyperotor from next model

#model15
model15_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    carbodyhatchback + enginetypel + enginetypeohc + enginetypeohcf + 
                    cylindernumberfive + cylindernumberthree + 
                    symboling.1 + CarCompanybmw + CarCompanybuick + CarCompanydodge + 
                    CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                    CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                    CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                  data = train)

summary(model15_car)

#Residual standard error: 1847 on 118 degrees of freedom
#Multiple R-squared:  0.9575,	Adjusted R-squared:  0.9489 
#F-statistic: 110.8 on 24 and 118 DF,  p-value: < 2.2e-16

#vif on model15
vif(model15_car)
#removing carbodyhatchback from next model as having highest p value

#model16
model16_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    enginetypel + enginetypeohc + enginetypeohcf + 
                    cylindernumberfive + cylindernumberthree + symboling.1 + 
                    CarCompanybmw + CarCompanybuick + CarCompanydodge + CarCompanyhonda + 
                    CarCompanyjaguar + CarCompanymazda + CarCompanymercury + 
                    CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                    CarCompanyrenault + CarCompanysaab + CarCompanytoyota + CarCompanyvolkswagen, 
                  data = train)
summary(model16_car)
#Residual standard error: 1853 on 119 degrees of freedom
#Multiple R-squared:  0.9569,	Adjusted R-squared:  0.9485 
#F-statistic: 114.8 on 23 and 119 DF,  p-value: < 2.2e-16

#vif on model16
vif(model16_car)
#removing CarCompanymercury from next model as having high pvalue

#model17

model17_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    enginetypel + enginetypeohc + enginetypeohcf + cylindernumberfive + 
                    cylindernumberthree + symboling.1 + CarCompanybmw + CarCompanybuick + 
                    CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                    CarCompanymitsubishi + CarCompanynissan + 
                    CarCompanyplymouth + CarCompanyrenault + CarCompanysaab + 
                    CarCompanytoyota + CarCompanyvolkswagen, data = train)
summary(model17_car)
#Residual standard error: 1870 on 120 degrees of freedom
#Multiple R-squared:  0.9557,	Adjusted R-squared:  0.9476 
#F-statistic: 117.7 on 22 and 120 DF,  p-value: < 2.2e-16

# vif on model17
vif(model17_car)
#removing CarCompanysaab from next model as having high p value

#model18
model18_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    enginetypel + enginetypeohc + enginetypeohcf + cylindernumberfive + 
                    cylindernumberthree + symboling.1 + CarCompanybmw + CarCompanybuick + 
                    CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                    CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                    CarCompanyrenault +  CarCompanytoyota + CarCompanyvolkswagen, 
                  data = train)
summary(model18_car)
#Residual standard error: 1887 on 121 degrees of freedom
#Multiple R-squared:  0.9545,	Adjusted R-squared:  0.9466 
#F-statistic: 120.9 on 21 and 121 DF,  p-value: < 2.2e-16

#vif on model18
vif(model18_car)
#removing symboling.1   as having high p value

#model19
model19_car <- lm(formula = price ~ aspiration + enginelocation + carwidth + 
                    enginetypel + enginetypeohc + enginetypeohcf + cylindernumberfive + 
                    cylindernumberthree +  CarCompanybmw + CarCompanybuick + 
                    CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                    CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                    CarCompanyrenault + CarCompanytoyota + CarCompanyvolkswagen, 
                  data = train)

summary(model19_car)

#Residual standard error: 1911 on 122 degrees of freedom
#Multiple R-squared:  0.953,	Adjusted R-squared:  0.9453 
#F-statistic: 123.7 on 20 and 122 DF,  p-value: < 2.2e-16

#vif on model19
vif(model19_car)
#removing aspiration from next model as having high p value

#model20

model20_car <- lm(formula = price ~  enginelocation + carwidth + 
                    enginetypel + enginetypeohc + enginetypeohcf + cylindernumberfive + 
                    cylindernumberthree + CarCompanybmw + CarCompanybuick + CarCompanydodge + 
                    CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + CarCompanymitsubishi + 
                    CarCompanynissan + CarCompanyplymouth + CarCompanyrenault + 
                    CarCompanytoyota + CarCompanyvolkswagen, data = train)
summary(model20_car)
#Residual standard error: 1929 on 123 degrees of freedom
#Multiple R-squared:  0.9517,	Adjusted R-squared:  0.9443 
#F-statistic: 127.6 on 19 and 123 DF,  p-value: < 2.2e-16

#vif on model20
vif(model20_car)
#removing cylindernumberthree from next model as having high p value

#model21
model21_car <- lm(formula = price ~ enginelocation + carwidth + enginetypel + 
                    enginetypeohc + enginetypeohcf + cylindernumberfive +  
                    CarCompanybmw + CarCompanybuick + CarCompanydodge + CarCompanyhonda + 
                    CarCompanyjaguar + CarCompanymazda + CarCompanymitsubishi + 
                    CarCompanynissan + CarCompanyplymouth + CarCompanyrenault + 
                    CarCompanytoyota + CarCompanyvolkswagen, data = train)

summary(model21_car)
#Residual standard error: 1960 on 124 degrees of freedom
#Multiple R-squared:  0.9498,	Adjusted R-squared:  0.9425 
#F-statistic: 130.2 on 18 and 124 DF,  p-value: < 2.2e-16

#vif on model21
vif(model21_car)
#removing cylindernumberfive from next as having high p value

#model22

model22_car <- lm(formula = price ~ enginelocation + carwidth + enginetypel + 
                    enginetypeohc + enginetypeohcf +  CarCompanybmw + 
                    CarCompanybuick + CarCompanydodge + CarCompanyhonda + CarCompanyjaguar + 
                    CarCompanymazda + CarCompanymitsubishi + CarCompanynissan + 
                    CarCompanyplymouth + CarCompanyrenault + CarCompanytoyota + 
                    CarCompanyvolkswagen, data = train)
summary(model22_car)

#Residual standard error: 1990 on 125 degrees of freedom
#Multiple R-squared:  0.9478,	Adjusted R-squared:  0.9407 
#F-statistic: 133.4 on 17 and 125 DF,  p-value: < 2.2e-16

#vif on model22
vif(model22_car)
#removing CarCompanydodge from next as having high p value

#model23

model23_car <- lm(formula = price ~ enginelocation + carwidth + enginetypel + 
                    enginetypeohc + enginetypeohcf + CarCompanybmw + CarCompanybuick + 
                    CarCompanyhonda + CarCompanyjaguar + CarCompanymazda + 
                    CarCompanymitsubishi + CarCompanynissan + CarCompanyplymouth + 
                    CarCompanyrenault + CarCompanytoyota + CarCompanyvolkswagen, 
                  data = train)
summary(model23_car)
#Residual standard error: 2033 on 126 degrees of freedom
#Multiple R-squared:  0.9451,	Adjusted R-squared:  0.9381 
#F-statistic: 135.5 on 16 and 126 DF,  p-value: < 2.2e-16


#vif on model23
vif(model23_car)


# predicting the results in test dataset

# Now all variables are significant as PVALUE is less than 0.05
Predict_car <- predict(model23_car,test[,-18])
test$test_price <- Predict_car
test$error <- test$price - test$test_price
# Now, we need to test the r square between actual and predicted sales. 
r <- cor(test$price,test$test_price)
rsquared <- cor(test$price,test$test_price)^2
rsquared
#0.7924425
#ploting for predicted price and actual price
ggplot(test,aes(1:nrow(test),y=price)) + geom_line(aes(colour="Actual Price")) + 
  scale_x_continuous(name = "rows",breaks = seq(0,65,15),limits = c(0,65)) + 
  scale_y_continuous(name="Price",breaks = seq(0,50000,10000),limits = c(0,50000)) + geom_line(aes(x=1:nrow(test),y=test_price,colour="Predicted Price")) 

# Plot  errors
ggplot(test, aes(1:nrow(test), error)) + geom_point() + 
  scale_x_continuous(name = "rows", breaks = seq(0,65,15), limits = c(0,65)) + 
  scale_y_continuous(name = "Error", breaks = seq(-50000,50000,10000), limits = c(-50000,50000)) + geom_hline(yintercept = 0)
ggplot(test, aes(1:nrow(test), error)) + geom_line() + 
  scale_x_continuous(name = "rows", breaks = seq(0,65,15), limits = c(0,65)) + 
  scale_y_continuous(name = "Error", breaks = seq(-50000,50000,10000), limits = c(-50000,50000)) + geom_hline(yintercept = 0)


#Variables significant for the pricing of car
#enginelocation   
#carwidth  
#enginetypel
#enginetypeohc
#enginetypeohcf
#CarCompanybmw 
#CarCompanybuick
#CarCompanyjaguar
#CarCompanymazda
#CarCompanymitsubishi
#CarCompanynissan
#CarCompanyplymouth
#CarCompanyrenault
#CarCompanytoyota
#CarCompanyvolkswagen