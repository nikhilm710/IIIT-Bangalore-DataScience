library(dplyr)
library(stringr)
library(tidyr)

# Checkpoin1
companies <- read.delim("companies.txt")
rounds2 <- read.csv("rounds2.csv",stringsAsFactors = FALSE)
rounds2$company_permalink <- tolower(rounds2$company_permalink)
companies$permalink <-  tolower(companies$permalink)

# unique companies  present in rounds2
unique_companies_round2 <-  n_distinct(rounds2$company_permalink)
unique_companies_round2
#unique companies are present in the companies file
unique_companies_companies <- n_distinct(companies$permalink)
unique_companies_companies

# Merge companies and rounds file
identical(unique(rounds2$company_permalink),companies$permalink)
master_frame <- merge(rounds2,companies,by.x = "company_permalink",by.y = "permalink")


#checkpoint2
# Average Values of Investments for Each of these Funding Types
Avg_Funding_Type <- master_frame %>% group_by(funding_round_type) %>% summarise(avg = mean(raised_amount_usd,na.rm = TRUE)) %>% filter(funding_round_type %in% c("venture","angel","seed","private_equity"))
Avg_Funding_Type

#Best inverstment type between 5 million and 15 million
Best_Investment_type <- master_frame %>% group_by(funding_round_type) %>% summarise(avg = mean(raised_amount_usd,na.rm = TRUE)) %>% filter(avg > 5000000 & avg < 15000000)
Best_Investment_type


#checkpoint3
# Top nine countries based on the desending order of total raised amount group by country code

top9 <-  master_frame %>% filter(funding_round_type == "venture",country_code != "") %>% group_by(country_code) %>% summarise(total_country_investment = sum(raised_amount_usd,na.rm =TRUE)) %>% arrange(desc(total_country_investment)) %>% head(9)

#checkpoint4
# 
mapping <- read.csv("mapping.csv",stringsAsFactors = FALSE)

mapping <-  mapping %>% gather(main_sector,value,Automotive...Sports:Social..Finance..Analytics..Advertising)
mapping <-  mapping[!(mapping$value == 0),]
mapping <-  mapping[,-3]
mapping<- mapping[!(mapping$category_list)=="",]

master_frame <- master_frame %>% mutate(primary_sector = word(category_list,1,sep = "\\|"))

master_frame <-  merge(master_frame,mapping,by.x = "primary_sector",by.y = "category_list")
#master_frame <-  merge(master_frame,mapping,by.x = "primary_sector",by.y = "category_list",all.x = TRUE)
#sum(is.na.data.frame(master_frame))
#write.csv(master_frame,"master_frame.csv")
#checkpoint5
D1 <-  master_frame %>% filter(country_code == "USA",funding_round_type == "venture",(raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)) %>% group_by(main_sector) %>% mutate(total_no_investment = n(),total_amt_investment = sum(raised_amount_usd,na.rm = TRUE))

D2 <-  master_frame %>% filter(country_code == "GBR",funding_round_type == "venture",(raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)) %>% group_by(main_sector) %>% mutate(total_no_investment = n(),total_amt_investment = sum(raised_amount_usd,na.rm = TRUE))

D3 <-  master_frame %>% filter(country_code == "IND",funding_round_type == "venture",(raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)) %>% group_by(main_sector) %>% mutate(total_no_investment = n(),total_amt_investment = sum(raised_amount_usd,na.rm = TRUE))

#Total number of Investments (count) for USA
sum(unique(D1$total_no_investment))
#Total number of Investments (count) for GBR
sum(unique(D2$total_no_investment))

#Total number of Investments (count) for IND
sum(unique(D3$total_no_investment))


#D1 %>% distinct(main_sector,total_amt_investment) %>% summarise(sum(total_amt_investment))
#Total amount of investment (USD) - USA
sum(unique(D1$total_amt_investment))
#Total amount of investment (USD) - GBR
sum(unique(D2$total_amt_investment))
#Total amount of investment (USD) - IND
sum(unique(D3$total_amt_investment))

#Sector name (no. of investment-wise) - USA
tot_sec_invest_D1 <- D1 %>% distinct(main_sector,total_no_investment) %>% arrange(desc(total_no_investment))
tot_sec_invest_D1

#Sector name (no. of investment-wise) - GBR
tot_sec_invest_D2 <- D2 %>% distinct(main_sector,total_no_investment) %>% arrange(desc(total_no_investment))
tot_sec_invest_D2

#Sector name (no. of investment-wise) - IND
tot_sec_invest_D3 <- D3 %>% distinct(main_sector,total_no_investment) %>% arrange(desc(total_no_investment))
tot_sec_invest_D3
#D1$raised_amount_usd <- as.numeric(D1$raised_amount_usd)

  options(scipen = 2) 

#company received the highest investment - USA- grouped by main sector and company name
D1 %>% filter(main_sector == "Others") %>% group_by(main_sector,name) %>% summarise(raised_amount_usd =  sum(raised_amount_usd)) %>% arrange(desc(raised_amount_usd)) %>% select(name,raised_amount_usd) 
#company received the second highest investment - USA - grouped by main sector and company name
D1 %>% filter(main_sector == "Cleantech...Semiconductors") %>% group_by(main_sector,name) %>% summarise(raised_amount_usd =  sum(raised_amount_usd)) %>% arrange(desc(raised_amount_usd)) %>% select(name,raised_amount_usd)

#company received the highest investment - GBR- grouped by main sector and company name
D2 %>% filter(main_sector == "Others") %>% group_by(main_sector,name) %>% summarise(raised_amount_usd =  sum(raised_amount_usd)) %>% arrange(desc(raised_amount_usd)) %>% select(name,raised_amount_usd) 
##company received the second highest investment - GBR - grouped by main sector and company name
D2 %>% filter(main_sector == "Cleantech...Semiconductors") %>% group_by(main_sector,name) %>% summarise(raised_amount_usd =  sum(raised_amount_usd)) %>% arrange(desc(raised_amount_usd)) %>% select(name,raised_amount_usd)


##company received the highest investment - IND- grouped by main sector and company name
D3 %>% filter(main_sector == "Others") %>% group_by(main_sector,name) %>% summarise(raised_amount_usd =  sum(raised_amount_usd)) %>% arrange(desc(raised_amount_usd)) %>% select(name,raised_amount_usd) 
## #company received the second highest investment - IND- grouped by main sector and company name
D3 %>% filter(main_sector == "News..Search.and.Messaging") %>% group_by(main_sector,name) %>% summarise(raised_amount_usd =  sum(raised_amount_usd)) %>% arrange(desc(raised_amount_usd)) %>% select(name,raised_amount_usd)
