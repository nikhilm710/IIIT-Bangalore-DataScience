#############################Telecom Solution###################
################################################################
#Business Understanding
#Data Understanding
#Data Preparation & EDA
#Model Building 
#Model Evaluation
################################################################

### Business Understanding:

# Based on the genral data of the employee  
# based on manager survey data and then employee survey data
# Based on in time and out time of an employee


## AIM:

# The aim is to predict probability of attrition using a logistic regression.
# if an emplyee would leave the current company and to find out the factors which will be important




################################################################

### Data Understanding

# Install and Load the required packages
#install.packages("MASS")
#install.packages("car")
#install.packages("e1071")
#install.packages("caret", dependencies = c("Depends", "Suggests"))
#install.packages("cowplot")
#install.packages("GGally")

library(MASS)
library(car)
library(e1071)
library(caret)
library(ggplot2)
library(cowplot)
library(caTools)
library(rpart)
library(rpart.plot)
library(effects)
library(mosaic)
library(plotly)
library(tidyr)
library(reshape2)
library(corrplot)
library(lubridate)
library(scales)
library(dplyr)
library(VIM)

# Loading 5 original files
employee_survey_data<- read.csv("employee_survey_data.csv", stringsAsFactors = F)
general_data<- read.csv("general_data.csv", stringsAsFactors = F)
manager_survey_data <- read.csv("manager_survey_data.csv", stringsAsFactors = F)
in_time <- read.csv("in_time.csv", stringsAsFactors = F)
out_time <- read.csv("out_time.csv", stringsAsFactors = F)




str(general_data)    # 4410 obs of 24 variables including the target variable
str(employee_survey_data) # 4410 obs of 4 variables 
str(manager_survey_data) # 4410 obs of 4 variables 

# Collate the data together in one single file

setdiff(general_data$EmployeeID,employee_survey_data$EmployeeID) # Identical customerID across these datasets
setdiff(general_data$EmployeeID,manager_survey_data$EmployeeID) # Identical customerID across these datasets
data_merge<- merge(general_data,employee_survey_data, by="EmployeeID", all = F)
data_merge<- merge(data_merge,manager_survey_data, by="EmployeeID", all = F)

##Now, let's check in time and out time files, we will take mean of in-time and out-timefor all employees and the difference between 2
colnames(in_time)[1] <- "EmployeeID"
colnames(out_time)[1] <- "EmployeeID"

##Removing all columns with NA from in_time and out_time files
in_time <- Filter(function(x)!all(is.na(x)), in_time)
out_time <- Filter(function(x)!all(is.na(x)), out_time)

##Counting number of leaves taken by an employee
in_time$number_of_leaves <- rowSums(is.na(in_time))

##Taking mean of in time and out time per employee

in_time[,2:250] <- lapply(in_time[,2:250],function(x) as.POSIXct(x,"%Y-%m-%d %H:%M"))
out_time[,2:250] <- lapply(out_time[,2:250],function(x) as.POSIXct(x,"%Y-%m-%d %H:%M"))
t1<-in_time[,2:250]
t2<-out_time[,2:250]
str(z)
z <- t2-t1
for (i in 1:4410){
z[i,250] <- mean(as.numeric(z[i,]), na.rm = TRUE)
}
colnames(z)[250] <- "mean_time_in_office"

time <- data.frame (cbind(in_time$EmployeeID, in_time$number_of_leaves, z$mean_time_in_office))
colnames(time) <- c("EmployeeID", "number_of_leaves", "mean_time_in_office")

##Creating master file by merging time and data merge

data_merge<- merge(data_merge,time, by="EmployeeID", all = F)


################################################################

### Data Preparation & Exploratory Data Analysis

# Understanding the structure of the collated file
str(data_merge) #4410 obs. of 31 variables;

# Age, monthly income, number of leaves, percent salary hike,  mean time in office are continuous



# Barcharts for categorical features 
bar_theme1<- theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), 
                   legend.position="none")



plot_grid(ggplot(data_merge, aes(x=BusinessTravel,fill=Attrition))+ geom_bar(), 
          ggplot(data_merge, aes(x=BusinessTravel,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=Department,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=EducationField,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=Gender,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=factor(JobLevel),fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h")   

plot_grid(ggplot(data_merge, aes(x=factor(Education),fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=MaritalStatus,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=factor(StockOptionLevel),fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h") 

plot_grid(ggplot(data_merge, aes(x=factor(EnvironmentSatisfaction),fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=factor(JobSatisfaction),fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=factor(WorkLifeBalance),fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=factor(JobInvolvement),fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=factor(PerformanceRating),fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(data_merge, aes(x=factor(YearsSinceLastPromotion),fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h") 

#Attrition is more in R&D department, in employees serving at 1,2 job levels, in edcuation in Life Sciences. 
#Employees who are single and education level as 3,4 and worked companies 1 and stock option with 0,1 have higher chances of attrition.

# Histogram and Boxplots for numeric variables 
box_theme<- theme(axis.line=element_blank(),axis.title=element_blank(), 
                  axis.ticks=element_blank(), axis.text=element_blank())


box_theme_y<- theme(axis.line.y=element_blank(),axis.title.y=element_blank(), 
                    axis.ticks.y=element_blank(), axis.text.y=element_blank(),
                    legend.position="none")


plot_grid(ggplot(data_merge, aes(YearsAtCompany, fill=Attrition))+ geom_histogram(binwidth = 20),
          ggplot(data_merge, aes(x="",y=YearsAtCompany))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(data_merge, aes(number_of_leaves, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=number_of_leaves))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 


plot_grid(ggplot(data_merge, aes(MonthlyIncome, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=MonthlyIncome))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(data_merge, aes(mean_time_in_office, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=MonthlyIncome))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(data_merge, aes(NumCompaniesWorked, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=NumCompaniesWorked))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)
plot_grid(ggplot(data_merge, aes(PercentSalaryHike, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=PercentSalaryHike))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)
plot_grid(ggplot(data_merge, aes(TotalWorkingYears, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=TotalWorkingYears))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(data_merge, aes(YearsWithCurrManager, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=YearsWithCurrManager))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(data_merge, aes(Age, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=Age))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(data_merge, aes(DistanceFromHome, fill=Attrition))+ geom_histogram(),
          ggplot(data_merge, aes(x="",y=DistanceFromHome))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)



#No outliers in numeric variables

# Boxplots of numeric variables relative to Attrition status
plot_grid(ggplot(data_merge, aes(x=Attrition,y=YearsAtCompany, fill=Attrition))+ geom_boxplot(width=0.2)+ 
            coord_flip() +theme(legend.position="none"),
          ggplot(data_merge, aes(x=Attrition,y=number_of_leaves, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(data_merge, aes(x=Attrition,y=MonthlyIncome, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(data_merge, aes(x=Attrition,y=mean_time_in_office, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(data_merge, aes(x=Attrition,y=NumCompaniesWorked, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(data_merge, aes(x=Attrition,y=PercentSalaryHike, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(data_merge, aes(x=Attrition,y=TotalWorkingYears, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(data_merge, aes(x=Attrition,y=YearsWithCurrManager, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(data_merge, aes(x=Attrition,y=Age, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(data_merge, aes(x=Attrition,y=DistanceFromHome, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          align = "v",nrow = 1)

# Shorter tenure and income < 50K tend to leave company

#Data Preparation
# Bringing the variables in the correct format
#gender - male =1,female=0
data_merge$Gender<- ifelse(data_merge$Gender=="Male", 1,0)

# Outlier treatment and imputing missing value

#Missing value
sapply(data_merge, function(x) sum(is.na(x)))
#25 NA's in EnvironmentSatisfaction- 25/4410
#,9 NA's in TotalWorkingYears,
#20 NA's in JobSatisfaction,
#19 NA's in NumCompaniesWorked, 
#38 NA's in WorkLifeBalance
#Treating NA's of EnvironmentSatisfaction
summary(data_merge$EnvironmentSatisfaction)
#we can replace NA of EnvironmentSatisfaction to 0 means they are neutral
data_merge$EnvironmentSatisfaction[which(is.na(data_merge$EnvironmentSatisfaction))] <-  0

#treating NA's of TotalWorkingYears-9/4410=0.2 % of data - we can remove them

View(subset(data_merge,is.na(TotalWorkingYears)))
data_merge <- data_merge[!(is.na(data_merge$TotalWorkingYears)),]

#Treating NA's for JobSatisfaction
View(subset(data_merge,is.na(JobSatisfaction)))
#we can replace NA of JobSatisfaction to 0 means they are neutral
data_merge$JobSatisfaction[which(is.na(data_merge$JobSatisfaction))] <-  0

#treating NA's for NumCompaniesWorked-19/4401=0.4% of the data - we can remove them
View(subset(data_merge,is.na(NumCompaniesWorked)))
data_merge <- data_merge[!(is.na(data_merge$NumCompaniesWorked)),]
#Treating NA's for WorkLifeBalance-18/4382=0.4% of the data - we can remove them
View(subset(data_merge,is.na(WorkLifeBalance)))
data_merge <- data_merge[!(is.na(data_merge$WorkLifeBalance)),]

# Correlation between numeric variables
data_merge_cor <- subset(data_merge, select = c(YearsAtCompany,number_of_leaves,MonthlyIncome, mean_time_in_office,NumCompaniesWorked, 
                                                PercentSalaryHike, TotalWorkingYears,YearsWithCurrManager,Age,DistanceFromHome))
corMTX <- cor(data.frame(data_merge_cor))
corrplot(corMTX, method = "number", type = "lower", order = "FPC", tl.cex=0.6 )
diag(corMTX) <- 0 
plot( levelplot(corMTX, 
                main ="Correlation matrix",
                scales=list(x=list(rot=90), cex=1.0)))

corrplot(corMTX, method="number")

#Boxplot showed no outlier, Nevertheless confirming it also with percentiles
sapply(data_merge_cor, 
       function(x) quantile(x,seq(0,1,.01),na.rm = T)) #no outlier

#There is no corelation between numeric variables

################################################################
# Feature standardisation

# Normalising continuous features 
data_merge$Age <-  scale(data_merge$Age)
data_merge$DistanceFromHome <-  scale(data_merge$DistanceFromHome)
data_merge$MonthlyIncome <- scale(data_merge$MonthlyIncome) 
data_merge$NumCompaniesWorked <- scale(data_merge$NumCompaniesWorked)
data_merge$PercentSalaryHike <-  scale(data_merge$PercentSalaryHike)
data_merge$TotalWorkingYears <-  scale(data_merge$TotalWorkingYears)
data_merge$TrainingTimesLastYear <- scale(data_merge$TrainingTimesLastYear)
data_merge$YearsAtCompany <- scale(data_merge$YearsAtCompany)
data_merge$YearsSinceLastPromotion <-  scale(data_merge$YearsSinceLastPromotion)
data_merge$YearsWithCurrManager <-  scale(data_merge$YearsWithCurrManager)
data_merge$number_of_leaves <-  scale(data_merge$number_of_leaves)
data_merge$mean_time_in_office <- scale(data_merge$mean_time_in_office)


summary(data_merge$StandardHours)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#8       8       8       8       8       8 
unique(data_merge$StandardHours)

#8
# there is only one value of StandardHours i.e 8, it will not play any significant role in the analysis
#will remove StandardHours

summary(data_merge$EmployeeCount)
#Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#1       1       1       1       1       1 
unique(data_merge$EmployeeCount)#1
# there is only one value of employee count i.e 1, it will not play any significant role in the analysis
#will remove employeecout
summary(data_merge$Over18)
unique(data_merge$Over18)
#All employees are above 18 so removing this variable also
data_merge <- data_merge[,-c(1, 9, 16, 18)]


################################################################################
# converting target variable Attrition from No/Yes character to factorwith levels 0/1 
data_merge$Attrition <- ifelse(data_merge$Attrition=="Yes", 1,0)

# Checking Attrition rate of employees
attrition <- sum(data_merge$Attrition)/nrow(data_merge)
attrition # 16.13%

#Creeating a data frame of categorical variable
data_merge_chr <- data_merge [, c(3,4,6,7,8,9,10,11,15,21,22,23,24,25 )]

# converting categorical attributes to factor
data_merge_fact<- data.frame(sapply(data_merge_chr, function(x) factor(x)))
str(data_merge_fact)

# creating dummy variables for factor attributes
dummies<- data.frame(sapply(data_merge_fact, 
                            function(x) data.frame(model.matrix(~x-1,data =data_merge_fact))[,-1]))

data_merge_final<- cbind(data_merge[,-c(3,4,6,7,8,9,10,11,15,21,22,23,24,25 )],dummies) 
str(data_merge_final)

########################################################################
# splitting the data between train and test
set.seed(100)

indices = sample.split(data_merge_final$Attrition, SplitRatio = 0.7)

train = data_merge_final[indices,]

test = data_merge_final[!(indices),]

########################################################################
# Logistic Regression: 

#Initial model
model_1 = glm(Attrition ~ ., data = train, family = "binomial")
summary(model_1) #AIC 2128.2

# Stepwise selection
library("MASS")
model_2<- stepAIC(model_1, direction="both")

summary(model_2)

# Removing multicollinearity through VIF check
library(car)
vif(model_2)

#Excluding YearsAtCompany
model_3<- glm(formula = Attrition ~ Age + DistanceFromHome + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                Department.xResearch...Development + Department.xSales + 
                JobLevel.x2 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + JobRole.xSales.Executive + MaritalStatus.xMarried + 
                MaritalStatus.xSingle + StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + 
                EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                JobInvolvement.x2 + JobInvolvement.x3 + JobInvolvement.x4, 
              family = "binomial", data = train)
summary(model_3)
vif(model_3)


#Excluding JonInvolvement.X2

model_4<- glm(formula = Attrition ~ Age + DistanceFromHome + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                Department.xResearch...Development + Department.xSales + 
                JobLevel.x2 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + JobRole.xSales.Executive + MaritalStatus.xMarried + 
                MaritalStatus.xSingle + StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + 
                EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                JobInvolvement.x3 + JobInvolvement.x4, 
              family = "binomial", data = train)
summary(model_4)
vif(model_4)


#Excluding  BusinessTravel.xTravel_Rarely

model_5<- glm(formula = Attrition ~ Age + DistanceFromHome + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                BusinessTravel.xTravel_Frequently + 
                Department.xResearch...Development + Department.xSales + 
                JobLevel.x2 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + JobRole.xSales.Executive + MaritalStatus.xMarried + 
                MaritalStatus.xSingle + StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + 
                EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                JobInvolvement.x3 + JobInvolvement.x4, 
              family = "binomial", data = train)
summary(model_5)
vif(model_5)



#Excluding  MaritalStatus.xMarried  

model_6<- glm(formula = Attrition ~ Age + DistanceFromHome + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                BusinessTravel.xTravel_Frequently + 
                Department.xResearch...Development + Department.xSales + 
                JobLevel.x2 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                MaritalStatus.xSingle + StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + 
                EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                JobInvolvement.x3 + JobInvolvement.x4, 
              family = "binomial", data = train)
summary(model_6)
vif(model_6)



#Excluding JobInvolvement.x4     


model_7<- glm(formula = Attrition ~ Age + DistanceFromHome + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                BusinessTravel.xTravel_Frequently + 
                Department.xResearch...Development + Department.xSales + 
                JobLevel.x2 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                MaritalStatus.xSingle + StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + 
                EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                JobInvolvement.x3 , 
              family = "binomial", data = train)
summary(model_7)
vif(model_7)

#Excluding StockOptionLevel.x1   


model_8<- glm(formula = Attrition ~ Age + DistanceFromHome + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                BusinessTravel.xTravel_Frequently + 
                Department.xResearch...Development + Department.xSales + 
                JobLevel.x2 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                JobInvolvement.x3 , 
              family = "binomial", data = train)
summary(model_8)
vif(model_8)


#Excluding DistanceFromHome  


model_9<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                BusinessTravel.xTravel_Frequently + 
                Department.xResearch...Development + Department.xSales + 
                JobLevel.x2 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                JobInvolvement.x3 , 
              family = "binomial", data = train)
summary(model_9)
vif(model_9)



#Excluding JobRole.xManager  


model_10<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                BusinessTravel.xTravel_Frequently + 
                Department.xResearch...Development + Department.xSales + 
                JobLevel.x2  + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                JobInvolvement.x3 , 
              family = "binomial", data = train)
summary(model_10)
vif(model_10)



#Excluding JobRole.xManufacturing.Director  


model_11<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 Department.xResearch...Development + Department.xSales + 
                 JobLevel.x2+ 
                 JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                 JobInvolvement.x3 , 
               family = "binomial", data = train)
summary(model_11)
vif(model_11)


#Excluding JobLevel.x2


model_12<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 Department.xResearch...Development + Department.xSales + 
                 JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                 JobInvolvement.x3 , 
               family = "binomial", data = train)
summary(model_12)
vif(model_12)


#Excluding JobInvolvement.x3


model_13<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 Department.xResearch...Development + Department.xSales + 
                 JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 
                  , 
               family = "binomial", data = train)
summary(model_13)
vif(model_13)


#Excluding Department.xSales


model_14<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 Department.xResearch...Development + 
                 JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 
               , 
               family = "binomial", data = train)
summary(model_14)
vif(model_14)



#Excluding WorkLifeBalance.x2  


model_15<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 Department.xResearch...Development + 
                 JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + WorkLifeBalance.x3 + WorkLifeBalance.x4 
               , 
               family = "binomial", data = train)
summary(model_15)
vif(model_15)


#Excluding Department.xResearch...Development


model_16<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + WorkLifeBalance.x3 + WorkLifeBalance.x4 
               , 
               family = "binomial", data = train)
summary(model_16)
vif(model_16)


#Excluding WorkLifeBalance.x4


model_17<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 JobRole.xResearch.Director + JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + WorkLifeBalance.x3 
               , 
               family = "binomial", data = train)
summary(model_17)
vif(model_17)


#Excluding JobRole.xResearch.Director  


model_18<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x2 + JobSatisfaction.x3 + WorkLifeBalance.x3 
               , 
               family = "binomial", data = train)
summary(model_18)
vif(model_18)

#Excluding JobSatisfaction.x2 


model_19<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 JobRole.xSales.Executive  + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x3 + WorkLifeBalance.x3 
               , 
               family = "binomial", data = train)
summary(model_19)
vif(model_19)




#Excluding JobRole.xSales.Executive


model_20<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x3 + WorkLifeBalance.x3 
               , 
               family = "binomial", data = train)
summary(model_20)
vif(model_20)


#Excluding Age


model_21<- glm(formula = Attrition ~  NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + mean_time_in_office + 
                 BusinessTravel.xTravel_Frequently + 
                 MaritalStatus.xSingle  + EnvironmentSatisfaction.x2 + 
                 EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x1 + JobSatisfaction.x3 + WorkLifeBalance.x3 
               , 
               family = "binomial", data = train)
summary(model_21)
vif(model_21)




########################################################################
# With 16 significant variables in the model

final_model<- model_21

#######################################################################

### Model Evaluation

### Test Data ####

#predicted probabilities of Attrition for test data

test_pred = predict(final_model, type = "response", 
                    newdata = test[,-2])


# Let's see the summary 

summary(test_pred)

test$prob <- test_pred
View(test)
# Let's use the probability cutoff of 50%.

test_pred_Attrition <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_Attrition <- factor(ifelse(test$Attrition==1,"Yes","No"))


table(test_actual_Attrition,test_pred_Attrition)


#######################################################################
test_pred_Attrition <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))

#install.packages("e1071")
library(e1071)

test_conf <- confusionMatrix(test_pred_Attrition, test_actual_Attrition, positive = "Yes")
test_conf
#######################################################################

#########################################################################################
# Let's Choose the cutoff value. 
# 

# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_Attrition <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_Attrition, test_actual_Attrition, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}


# Summary of test probability

summary(test_pred)

s = seq(.01,.80,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 


plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.01)]


# Let's choose a cutoff value of 0.185 for final model

test_cutoff_Attrition <- factor(ifelse(test_pred >=0.185, "Yes", "No"))

conf_final <- confusionMatrix(test_cutoff_Attrition, test_actual_Attrition, positive = "Yes")

acc <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

acc

sens

spec

View(test)
##################################################################################################
### KS -statistic - Test Data ######

test_cutoff_Attrition <- ifelse(test_cutoff_Attrition=="Yes",1,0)
test_actual_Attrition <- ifelse(test_actual_Attrition=="Yes",1,0)


library(ROCR)
#on testing  data
pred_object_test<- prediction(test_cutoff_Attrition, test_actual_Attrition)

performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)


####################################################################
# Lift & Gain Chart 

# plotting the lift chart

# Loading dplyr package 
require(dplyr)
library(dplyr)

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Attrition_decile = lift(test_actual_Attrition, test_pred, groups = 10)